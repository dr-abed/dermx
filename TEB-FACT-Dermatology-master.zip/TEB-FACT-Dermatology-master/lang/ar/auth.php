<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'هذه البيانات غير متطابقة مع سجلاتنا.',
    'password' => 'كلمة المرور غير صحيحة.',
    'throttle' => 'عدد محاولات تسجيل الدخول كثيرة. الرجاء المحاولة مرة أخرى بعد :seconds ثواني.',
    'logged-out' => 'لقد تم تسجيل الخروج بنجاح.',
    'password-reset' => 'تم تغيير كلمة المرور بنجاح.',
    'pin-code-send' => 'الرجاء التحقق من بريدك الإلكتروني للحصول على رمز التحقق المكون من 6 أرقام.',
    'email-verified' => 'تم التحقق من البريد الإلكتروني بنجاح.',
    'invalid-pin' => 'رمز التحقق غير صحيح.',
    'pin-verified' => 'تم التحقق من رمز التحقق بنجاح.',
    'email-verified-but-not-approved' => 'تم التحقق من البريد الإلكتروني بنجاح ، ولكن لم يتم الموافقة على حسابك بعد.',
    'dermatologist_not_approved_yet' => 'لم يتم الموافقة على حسابك بعد.',
];
