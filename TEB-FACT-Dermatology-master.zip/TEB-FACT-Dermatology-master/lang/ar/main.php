<?php
return [

    /*
    |--------------------------------------------------------------------------
    | Main Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during main for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    "PatientHistoryQuestionType" => [
        "textarea" => "حقل نصي",
        "radio" => "اختيار واحد",
        "trueFalse" => "صحيح/خطأ",
        "checkbox" => "اختيارات متعددة"
    ],
    "GenderType" => [
        "male" => "ذكر",
        "female" => "أنثى"
    ],
    "DermatologistProfileStatus" => [
        "notVerified" => "غير مفعل",
        "inComplete" => "غير مكتمل",
        "notApproved" => "غير معتمد",
        "approved" => "معتمد"
    ],
    "question" => "سؤال",
    "questions" => "الأسئلة",
    "admin" => "مدير",
    "admins" => "المدراء",
    "patients"=> "المرضى",
    "patient" => "مريض",
    "dermatologists" => "الطبيبين الجلديين",
    "dermatologist" => "طبيب جلدي",
    "pages" => "الصفحات",
    "page" => "صفحة",
    "contactMessages" => "رسائل الاتصال",
    "contactMessage" => "رسالة اتصال",
    "consultations" => "الاستشارات",
    "consultation" => "استشارة",
    "data" => "البيانات",
    "consultation_not_new" => "لا يمكن حذف الاستشارة لأنها ليست جديدة",
    "not_allowed" => "غير مسموح",
    "consultation_not_closed" => "لا يمكن تقييم الاستشارة لأنها ليست مغلقة",
    "consultation_rate" => "تقييم الاستشارة",
    "consultation_already_rated" => "لا يمكن تقييم الاستشارة لأنها مقيمة بالفعل",
    "there_is_no_remaining_consultations" => "لا يوجد استشارات متبقية",
    "articles" => "المقالات",
    'article' => 'مقالة',
    "tebfact" => "طب فاكت",
    'icon' => 'الأيقونة',
    'advertisement' => 'إعلان',
    'advertisements' => 'الإعلانات',
    'patient_histories_not_answered' => 'لا يمكنك إنشاء استشارة لأن هناك أسئلة لم يتم الإجابة عليها',
    'site_setting' => 'إعدادات الموقع',
    'fcm_token' => 'رمز FCM',
    'notifications' => 'الإشعارات',
    'unseen_count' => 'عدد الرسائل الغير مقروءة',
    'patient_history' => 'سجل المريض',
];
