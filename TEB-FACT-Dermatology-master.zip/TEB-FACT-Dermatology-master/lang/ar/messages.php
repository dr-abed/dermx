<?php

return [
    'not_found' => 'لم يتم العثور على :message',
    'retrived' => 'تم إسترجاع :message بنجاح',
    'created' => 'تم إضافة :message بنجاح',
    'updated' => 'تم تحديث :message بنجاح',
    'sent' => 'تم إرسال :message بنجاح',
    'activated' => 'تم تفعيل :message بنجاح',
    'deactivated' => 'تم إلغاء تفعيل :message بنجاح',
    'deleted' => 'تم حذف :message بنجاح',
    'cancelled' => 'تم إلغاء :message بنجاح',
    'contact_success' => 'تم إرسال الرسالة بنجاح',
    'cant_delete_parent' => 'لا يمكن حذف السجل لإرتباطه بسجلات أخرى:',
    'cant_delete_parent_short' => 'لا يمكن حذف السجل لإرتباطه بسجلات أخرى',
    'package_link_text' => ' أريد الحصول على',
    'valid' => 'التوكن صالح',
    'invalid' => 'التوكن غير صالح',
    'consultation_status_changed' => [
        'New' => 'تم إنشاء الإستشارة بنجاح',
        'Open' => 'تم فتح الإستشارة بنجاح',
        'Closed' => 'تم إغلاق الإستشارة بنجاح',
        'Canceled' => 'تم إلغاء الإستشارة بنجاح',
    ],
    'consultation_status_changed_body' => [
        'New' => 'لقد تلقينا طلب الإستشارة الخاص بك، وسنتواصل معك قريباً',
        'Open' => 'يمكنك الآن بدء الإستشارة!',
        'Closed' => 'شكراً لإستخدامك لخدماتنا!',
        'Canceled' => 'نأمل أن نراك مرة أخرى قريباً',
    ],
    'missing_data' => 'الرجاء إدخال جميع البيانات المطلوبة',
    'received_new_message' => 'لديك رسالة جديدة',
];
