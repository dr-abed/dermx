<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'accepted' => 'يجب قبول :attribute',
    'accepted_if' => 'يجب قبول :attribute عندما يكون :other :value.',
    'active_url' => ' :attribute ليس عنوان URL صالحًا.',
    'after' => ' :attribute يجب أن يكون تاريخًا بعد :date.',
    'after_or_equal' => ' :attribute يجب أن يكون تاريخًا بعد أو يساوي :date.',
    'alpha' => ' :attribute يجب أن يحتوي على حروف فقط.',
    'alpha_dash' => ' :attribute يجب أن يحتوي على حروف وأرقام وشرطات وشرطات سفلية فقط.',
    'alpha_num' => ' :attribute يجب أن يحتوي على حروف وأرقام فقط.',
    'array' => ' :attribute يجب أن يكون مصفوفة.',
    'before' => ' :attribute يجب أن يكون تاريخًا قبل :date.',
    'before_or_equal' => ' :attribute يجب أن يكون تاريخًا قبل أو يساوي :date.',
    'between' => [
        'numeric' => ' :attribute يجب أن يكون بين :min و :max.',
        'file' => ' :attribute يجب أن يكون بين :min و :max كيلوبايت.',
        'string' => ' :attribute يجب أن يكون بين :min و :max حرفًا.',
        'array' => ' :attribute يجب أن يكون بين :min و :max عنصرًا.',
    ],
    'boolean' => ' :attribute يجب أن يكون حقل صحيح أو خاطئ.',
    'confirmed' => ' :attribute تأكيد غير متطابق.',
    'current_password' => 'كلمة المرور غير صحيحة.',
    'date' => ' :attribute ليس تاريخًا صالحًا.',
    'date_equals' => ' :attribute يجب أن يكون تاريخًا يساوي :date.',
    'date_format' => ' :attribute لا يتطابق مع التنسيق :format.',
    'declined' => ' :attribute يجب أن يتم رفضه.',
    'declined_if' => ' :attribute يجب أن يتم رفضه عندما يكون :other :value.',
    'different' => ' :attribute و :other يجب أن يكونا مختلفين.',
    'digits' => ' :attribute يجب أن يكون :digits رقمًا.',
    'digits_between' => ' :attribute يجب أن يكون بين :min و :max رقمًا.',
    'dimensions' => ' :attribute له أبعاد صورة غير صالحة.',
    'distinct' => ' :attribute له قيمة مكررة.',
    'email' => ' :attribute يجب أن يكون عنوان بريد إلكتروني صالحًا.',
    'ends_with' => ' :attribute يجب أن ينتهي بأحد القيم التالية: :values.',
    'exists' => ' :attribute المحدد غير صالح.',
    'file' => ' :attribute يجب أن يكون ملفًا.',
    'filled' => ' :attribute يجب أن يكون له قيمة.',
    'gt' => [
        'numeric' => ' :attribute يجب أن يكون أكبر من :value.',
        'file' => ' :attribute يجب أن يكون أكبر من :value كيلوبايت.',
        'string' => ' :attribute يجب أن يكون أكبر من :value حرفًا.',
        'array' => ' :attribute يجب أن يكون أكبر من :value عنصرًا.',
    ],
    'gte' => [
        'numeric' => ' :attribute يجب أن يكون أكبر من أو يساوي :value.',
        'file' => ' :attribute يجب أن يكون أكبر من أو يساوي :value كيلوبايت.',
        'string' => ' :attribute يجب أن يكون أكبر من أو يساوي :value حرفًا.',
        'array' => ' :attribute يجب أن يكون :value عنصرًا أو أكثر.',
    ],
    'image' => ' :attribute يجب أن يكون صورة.',
    'in' => ' :attribute المحدد غير صالح.',
    'in_array' => ' :attribute غير موجود في :other.',
    'integer' => ' :attribute يجب أن يكون عددًا صحيحًا.',
    'ip' => ' :attribute يجب أن يكون عنوان IP صالحًا.',
    'ipv4' => ' :attribute يجب أن يكون عنوان IPv4 صالحًا.',
    'ipv6' => ' :attribute يجب أن يكون عنوان IPv6 صالحًا.',
    'json' => ' :attribute يجب أن يكون نصًا JSON صالحًا.',
    'lt' => [
        'numeric' => ' :attribute يجب أن يكون أقل من :value.',
        'file' => ' :attribute يجب أن يكون أقل من :value كيلوبايت.',
        'string' => ' :attribute يجب أن يكون أقل من :value حرفًا.',
        'array' => ' :attribute يجب أن يكون أقل من :value عنصرًا.',
    ],
    'lte' => [
        'numeric' => ' :attribute يجب أن يكون أقل من أو يساوي :value.',
        'file' => ' :attribute يجب أن يكون أقل من أو يساوي :value كيلوبايت.',
        'string' => ' :attribute يجب أن يكون أقل من أو يساوي :value حرفًا.',
        'array' => ' :attribute يجب أن لا يكون أكثر من :value عنصرًا.',
    ],
    'max' => [
        'numeric' => ' :attribute قد لا يكون أكبر من :max.',
        'file' => ' :attribute قد لا يكون أكبر من :max كيلوبايت.',
        'string' => ' :attribute قد لا يكون أكبر من :max حرفًا.',
        'array' => ' :attribute قد لا يكون أكثر من :max عنصرًا.',
    ],
    'mimes' => ' :attribute يجب أن يكون ملفًا من النوع: :values.',
    'mimetypes' => ' :attribute يجب أن يكون ملفًا من النوع: :values.',
    'min' => [
        'numeric' => ' :attribute يجب أن يكون على الأقل :min.',
        'file' => ' :attribute يجب أن يكون على الأقل :min كيلوبايت.',
        'string' => ' :attribute يجب أن يكون على الأقل :min حرفًا.',
        'array' => ' :attribute يجب أن يكون على الأقل :min عنصرًا.',
    ],
    'multiple_of' => ' :attribute يجب أن يكون مضاعفًا من :value.',
    'not_in' => ' :attribute المحدد غير صالح.',
    'not_regex' => ' :attribute الصيغة غير صالحة.',
    'numeric' => ' :attribute يجب أن يكون رقمًا.',
    'password' => 'كلمة المرور غير صحيحة.',
    'present' => ' :attribute يجب أن يكون موجودًا.',
    'regex' => ' :attribute الصيغة غير صالحة.',
    'required' => ' :attribute مطلوب.',
    'required_if' => ' :attribute مطلوب عندما يكون :other :value.',
    'required_unless' => ' :attribute مطلوب إلا إذا كان :other في :values.',
    'required_with' => ' :attribute مطلوب عندما يكون :values موجودًا.',
    'required_with_all' => ' :attribute مطلوب عندما يكون :values موجودًا.',
    'required_without' => ' :attribute مطلوب عندما :values غير موجود.',
    'required_without_all' => ' :attribute مطلوب عندما لا يكون أي من :values موجودًا.',
    'same' => ' :attribute و :other يجب أن يتطابقا.',
    'size' => [
        'numeric' => ' :attribute يجب أن يكون :size.',
        'file' => ' :attribute يجب أن يكون :size كيلوبايت.',
        'string' => ' :attribute يجب أن يكون :size حرفًا.',
        'array' => ' :attribute يجب أن يحتوي على :size عنصرًا.',
    ],
    'starts_with' => ' :attribute يجب أن يبدأ بأحد القيم التالية: :values.',
    'string' => ' :attribute يجب أن يكون نصًا.',
    'timezone' => ' :attribute يجب أن يكون منطقة صالحة.',
    'unique' => ' :attribute تم اختياره بالفعل.',
    'uploaded' => ' :attribute فشل في التحميل.',
    'url' => ' :attribute الصيغة غير صالحة.',
    'uuid' => ' :attribute يجب أن يكون UUID صالحًا.',


    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
        'attribute-name' => [
            'rule-name' => 'رسالة مخصصة',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap our attribute placeholder
    | with something more reader friendly such as "E-Mail Address" instead
    | of "email". This simply helps us make our message more expressive.
    |
    */

    'attributes' => [],

];
