<?php
return [


    /*
    |--------------------------------------------------------------------------
    | Main Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during main for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    "PatientHistoryQuestionType" => [
        "textarea" => "Textarea",
        "radio" => "Radio",
        "trueFalse" => "True/False",
        "checkbox" => "Checkbox"
    ],
    "GenderType" => [
        "male" => "Male",
        "female" => "Female"
    ],
    "DermatologistProfileStatus" => [
        "notVerified" => "Not Verified",
        "inComplete" => "In Complete",
        "notApproved" => "Not Approved",
        "approved" => "Approved"
    ],
    "question" => "Question",
    "questions" => "Questions",
    "admin" => "Admin",
    "admins" => "Admins",
    "patients"=> "Patients",
    "patient" => "Patient",
    "dermatologists" => "Dermatologists",
    "dermatologist" => "Dermatologist",
    "pages" => "Pages",
    "page" => "Page",
    "contactMessages" => "Contact Messages",
    "contactMessage" => "Contact Message",
    "consultations" => "Consultations",
    "consultation" => "Consultation",
    "data" => "Data",
    "consultation_not_new" => "You can't delete this consultation because it's not new",
    "not_allowed" => "You are not allowed to do this action",
    "consultation_not_closed" => "You can't rate this consultation because it's not closed",
    "consultation_rate" => "Consultation Rate",
    "consultation_already_rated" => "You already rated this consultation",
    "there_is_no_remaining_consultations" => "There is no remaining consultations",
    "articles" => "Articles",
    'article' => 'Article',
    "tebfact" => "TebFact",
    'icon' => 'Icon',
    'advertisement' => 'Advertisement',
    'advertisements' => 'Advertisements',
    'patient_histories_not_answered' => 'You can\'t create consultation because there is patient histories not answered',
    'site_setting' => 'Site Settings',
    'fcm_token' => 'FCM Token',
    'notifications' => 'Notifications',
    'unseen_count' => 'Unseen Notifications Count',
    'patient_history' => 'Patient History',
];
