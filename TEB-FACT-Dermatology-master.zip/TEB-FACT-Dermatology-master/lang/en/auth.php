<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'These credentials do not match our records.',
    'password' => 'The provided password is incorrect.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',
    'logged-out' => 'You have been successfully logged out.',
    'password-reset' => 'Your password has been changed successfully.',
    'pin-code-send' => 'Please check your email for a 6-digit pin to verify it.',
    'email-verified' => 'Your email has been verified successfully.',
    'invalid-pin' => 'Invalid pin code.',
    'pin-verified' => 'Your pin code has been verified successfully.',
    'email-verified-but-not-approved' => 'Your email has been verified successfully, but your account is not approved yet.',
    'dermatologist_not_approved_yet' => 'Your account is not approved yet.',
];
