<?php

return [
    'not_found' => ':message Not Found',
    'retrived' => ':message Retrieved Successfully',
    'created' => ':message Has Been Created Successfully',
    'updated' => ':message Has Been Updated Successfully',
    'sent' => ':message Has Been Sent Successfully',
    'activated' => ':message Has Been Activated Successfully',
    'deactivated' => ':message Has Been Deactivated Successfully',
    'deleted' => ':message Has Been Deleted Successfully',
    'cancelled' => ':message Has Been Cancelled Successfully',
    'contact_success' => 'Message Sent Successfully',
    'cant_delete_parent' => 'This Record Cannot Be Deleted Because It Is Linked to Other Records:',
    'cant_delete_parent_short' => 'This Record Cannot Be Deleted Because It Is Linked to Other Records',
    'package_link_text' => 'I Want To Get',
    'valid' => 'Token Is Valid',
    'invalid' => 'Token Is Invalid',
    'consultation_status_changed' => [
        'New' => 'Consultation Has Been Created Successfully',
        'Open' => 'Consultation Has Been Opened',
        'Closed' => 'Consultation Has Been Closed',
        'Canceled' => 'Consultation Has Been Canceled',
    ],
    'consultation_status_changed_body' => [
        'New' => 'We have received your consultation request, and we will contact you soon',
        'Open' => 'Now you can start your consultation!',
        'Closed' => 'Thank you for using our service!',
        'Canceled' => 'We hope to see you again soon',
    ],
    'missing_data' => 'Please Enter All Required Data',
    'received_new_message' => 'You Have A New Message',
];
