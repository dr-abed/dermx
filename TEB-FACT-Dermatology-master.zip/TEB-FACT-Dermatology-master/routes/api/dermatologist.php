<?php

use App\Http\Controllers\API\Admin\ContactMessageController;
use App\Http\Controllers\API\Mobile\Dermatologist\ArticleController;
use App\Http\Controllers\API\Mobile\Dermatologist\ConsultationController;
use App\Http\Controllers\API\Mobile\Dermatologist\DermatologistController;
use App\Http\Controllers\API\Mobile\Dermatologist\HomeController;
use App\Http\Controllers\API\Mobile\Dermatologist\NotificationController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => 'localization'], function () {

    Route::group(['middleware' => 'guest:dermatologist'], function () {
        Route::post('/register', [DermatologistController::class, 'register']);
        Route::post('/login', [DermatologistController::class, 'login']);
        Route::post('/send-forget-password-code', [DermatologistController::class, 'sendForgotPasswordEmail']);
        Route::post('/verify-forget-password-code', [DermatologistController::class, 'verifyForgotPassword']);
    });

    Route::group(['middleware' => ['auth:dermatologist', 'scopes:dermatologist']], function () {
        Route::post('/change-password', [DermatologistController::class, 'changePassword']);
        Route::post('/logout', [DermatologistController::class, 'logout']);
        Route::post('/update', [DermatologistController::class, 'update']);
        Route::get('/profile', [DermatologistController::class, 'profile']);
        Route::post('/complete-profile', [DermatologistController::class, 'completeProfile']);
        Route::post('/send-verification-code', [DermatologistController::class, 'sendEmailVerification']);
        Route::post('/verify-email', [DermatologistController::class, 'verifyEmail']);
        Route::post('/reset-password', [DermatologistController::class, 'resetPassword']);
        Route::post('/delete-account', [DermatologistController::class, 'destroy']);

        //Consultations Route:
        Route::get('/consultations', [ConsultationController::class, 'index']);
        Route::post('/consultations/{consultation}/take', [ConsultationController::class, 'take']);
        Route::post('/consultations/{consultation}/close', [ConsultationController::class, 'close']);
        Route::get('/new-consultations', [ConsultationController::class, 'new_consultations']);
        Route::get('/patient-history/{patient}', [ConsultationController::class, 'patient_history']);

        //Articles Route:
        Route::get('/articles', [ArticleController::class, 'index']);
        Route::get('/articles/{article}', [ArticleController::class, 'show']);
        Route::post('/articles/store', [ArticleController::class, 'store']);
        Route::post('/articles/{article}', [ArticleController::class, 'update']);
        Route::post('/articles/{article}/delete', [ArticleController::class, 'destroy']);

        //Contact Messages Route:
        Route::post('/contact-messages', [ContactMessageController::class, 'store']);

        //Home Route:
        Route::get('/home', [HomeController::class, 'index']);

        //Notifications Route:
        Route::post('/fcm', [NotificationController::class, 'updateFcm']);
        Route::get('/notifications', [NotificationController::class, 'index']);
        Route::post('/notifications', [NotificationController::class, 'seen']);
        Route::get('/notifications/unseen_count', [NotificationController::class, 'unseenCount']);
    });
});
