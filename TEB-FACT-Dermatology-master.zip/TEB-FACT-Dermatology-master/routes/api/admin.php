<?php

use App\Http\Controllers\API\Admin\ConsultationController;
use App\Http\Controllers\API\Admin\ContactMessageController;
use App\Http\Controllers\API\Admin\DermatologistController;
use App\Http\Controllers\API\Admin\PageController;
use App\Http\Controllers\API\Admin\PatientController;
use App\Http\Controllers\API\Admin\PatientHistoryQuestionController;
use App\Http\Controllers\API\Admin\AdminController;
use App\Http\Controllers\API\Admin\AdvertisementController;
use App\Http\Controllers\API\Admin\HomeController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => 'localization'], function () {

    Route::group(['middleware' => 'guest:admin'], function () {
        Route::post('/login', [AdminController::class, 'login']);
    });

    Route::group(['middleware' => ['auth:admin', 'scopes:admin']], function () {
        Route::post('/change-password', [AdminController::class, 'changePassword']);
        Route::post('/admins/{admin}', [AdminController::class, 'update']);
        Route::post('/logout', [AdminController::class, 'logout']);
        Route::get('/check-token', [AdminController::class, 'checkToken']);

        // Static Pages Routes:
        Route::get('/pages', [PageController::class, 'index']);
        Route::get('/pages/{page}', [PageController::class, 'show']);
        Route::post('/pages', [PageController::class, 'store']);
        Route::post('/pages/{page}', [PageController::class, 'update']);
        Route::post('pages/{page}/update-status', [PageController::class, 'updateStatus']);
        Route::delete('/pages/{page}', [PageController::class, 'destroy']);

        // General Patient History Questions:
        Route::get('/history-questions', [PatientHistoryQuestionController::class, 'index']);
        Route::post('/history-questions', [PatientHistoryQuestionController::class, 'store']);
        Route::post('/history-questions/{question}', [PatientHistoryQuestionController::class, 'update']);
        Route::delete('/history-questions/{question}', [PatientHistoryQuestionController::class, 'destroy']);

        //Contact Messages Routes:
        Route::get('/contact-messages', [ContactMessageController::class, 'index']);
        Route::get('/contact-messages/{contactMessage}', [ContactMessageController::class, 'show']);
        Route::post('/contact-messages/{contactMessage}/reply', [ContactMessageController::class, 'reply']);

        //Consultations Routes:
        Route::get('/consultations', [ConsultationController::class, 'index']);

        //Patients Routes:
        Route::get('/patients', [PatientController::class, 'index']);
        Route::get('/patients/{patient}', [PatientController::class, 'show']);
        Route::post('/patients/{patient}/', [PatientController::class, 'update']);
        Route::delete('/patients/{patient}', [PatientController::class, 'destroy']);

        //Dermatologists Routes:
        Route::get('/dermatologists', [DermatologistController::class, 'index']);
        Route::get('/dermatologists/{dermatologist}', [DermatologistController::class, 'show']);
        // Route::post('/dermatologists', [DermatologistController::class, 'store']);
        Route::post('/dermatologists/{dermatologist}', [DermatologistController::class, 'update']);
        // Route::post('/activate-dermatologist/{dermatologist}', [DermatologistController::class, 'activate']);
        Route::delete('/dermatologists/{dermatologist}', [DermatologistController::class, 'destroy']);

        //Dashboard Routes:
        Route::get('/home', [HomeController::class, 'index']);
        Route::get('/last-consultations', [HomeController::class, 'last_consultations']);
        Route::post('/update-site-setting', [PageController::class, 'updateSiteSetting']);


        //Advertisement Routes:
        Route::get('/sponsors', [AdvertisementController::class, 'index']);
        Route::get('/sponsors/{advertisement}', [AdvertisementController::class, 'show']);
        Route::post('/sponsors', [AdvertisementController::class, 'store']);
        Route::post('/sponsors/{advertisement}', [AdvertisementController::class, 'update']);
        Route::delete('/sponsors/{advertisement}', [AdvertisementController::class, 'destroy']);
    });
});
