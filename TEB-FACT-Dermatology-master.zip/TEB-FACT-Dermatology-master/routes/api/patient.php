<?php

use App\Http\Controllers\API\Admin\ContactMessageController;
use App\Http\Controllers\API\Mobile\Patient\ArticleController;
use App\Http\Controllers\API\Mobile\Patient\ConsultationController;
use App\Http\Controllers\API\Mobile\Patient\HomeController;
use App\Http\Controllers\API\Mobile\Patient\NotificationController;
use App\Http\Controllers\API\Mobile\Patient\PatientController;
use App\Http\Controllers\API\Mobile\Patient\PatientHistoryController;
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => 'localization'], function () {

    Route::group(['middleware' => 'guest:patient'], function () {
        Route::post('/register', [PatientController::class, 'register']);
        Route::post('/login', [PatientController::class, 'login']);
        Route::post('/send-forget-password-code', [PatientController::class, 'sendForgotPasswordEmail']);
        Route::post('/verify-forget-password-code', [PatientController::class, 'verifyForgotPassword']);
    });

    Route::group(['middleware' => ['auth:patient', 'scopes:patient']], function () {
        Route::post('/change-password', [PatientController::class, 'changePassword']);
        Route::post('/logout', [PatientController::class, 'logout']);
        Route::post('/update', [PatientController::class, 'update']);
        Route::get('/profile', [PatientController::class, 'profile']);
        Route::post('/send-verification-code', [PatientController::class, 'sendEmailVerification']);
        Route::post('/verify-email', [PatientController::class, 'verifyEmail']);
        Route::post('/reset-password', [PatientController::class, 'resetPassword']);
        Route::post('/delete-account', [PatientController::class, 'destroy']);

        //Patient History Route:
        Route::get('/patient-history', [PatientHistoryController::class, 'index']);
        Route::post('/patient-history', [PatientHistoryController::class, 'update']);

        //Consultation Route:
        Route::get('/consultations', [ConsultationController::class, 'index']);
        // Route::get('/consultations/{consultation}', [ConsultationController::class, 'show']);
        Route::post('/consultations/store', [ConsultationController::class, 'store']);
        Route::post('/consultations/{consultation}/cancel', [ConsultationController::class, 'cancel']);
        Route::post('/consultations/{consultation}/rate', [ConsultationController::class, 'rate']);

        //Contact Messages Route:
        Route::post('/contact-messages', [ContactMessageController::class, 'store']);

        //Home Route:
        Route::get('/home', [HomeController::class, 'index']);

        //Articles Route:
        Route::get('/articles', [ArticleController::class, 'index']);
        Route::get('/articles/{article}', [ArticleController::class, 'show']);

        //Notifications Route:
        Route::post('/fcm', [NotificationController::class, 'updateFcm']);
        Route::get('/notifications', [NotificationController::class, 'index']);
        Route::post('/notifications', [NotificationController::class, 'seen']);
        Route::get('/notifications/unseen_count', [NotificationController::class, 'unseenCount']);
    });
});
