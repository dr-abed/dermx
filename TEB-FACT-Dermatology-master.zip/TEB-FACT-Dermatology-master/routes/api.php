<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\Admin\PageController;
use App\Http\Controllers\API\Auth\SocialiteController;
use App\Http\Controllers\API\Mobile\SettingController;
use App\Http\Controllers\API\Mobile\Dermatologist\ConsultationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/settings', [SettingController::class, 'index'])->middleware('localization');
Route::post('/send-notification', [SettingController::class, 'sendNotification'])->middleware('localization');
Route::get('/pages/{page}', [PageController::class, 'show'])->middleware('localization');
Route::post('/auth/callback', [SocialiteController::class, 'handleProviderCallback'])->middleware('localization');

Route::get('/consultations/{consultation}', [ConsultationController::class, 'generalConsultation'])->middleware('auth:patient,dermatologist');

Route::prefix('admin')->group(fn () => require __DIR__ . '/api/admin.php');
Route::prefix('patient')->group(fn () => require __DIR__ . '/api/patient.php');
Route::prefix('dermatologist')->group(fn () => require __DIR__ . '/api/dermatologist.php');
