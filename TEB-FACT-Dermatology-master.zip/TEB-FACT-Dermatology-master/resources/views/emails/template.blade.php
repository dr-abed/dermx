@component('mail::layout')

@slot('header')
@endslot

{!! $body !!}

@slot('footer')
@endslot

@endcomponent
