<?php

use Carbon\Carbon;
use Illuminate\Mail\SentMessage;
use Illuminate\Support\Facades\File;

function encryptData($data)
{
    $information = $data;
    $cipher = config('app.cipher');
    $secret = config('app.secret');
    $options = 0;
    $iv = config('app.iv');
    $enc_string =  openssl_encrypt($information, $cipher, $secret, $options, $iv);
    return $enc_string;
}

function decryptData($data)
{
    $information = $data;
    $cipher = config('app.cipher');
    $secret = config('app.secret');
    $options = 0;
    $iv = config('app.iv');
    $dec_string = openssl_decrypt($information, $cipher, $secret, $options, $iv);
    return $dec_string;
}

function getClassesList($dir)
{
    return array_map(fn ($f) => str_replace([app_path(), '/', '.php'], ['App', '\\', ''], $f->getRealPath()), File::allFiles($dir));
}

if (!function_exists('carbon')) {
    function carbon($date)
    {
        return Carbon::parse($date);
    }
}

if (!function_exists('get_table')) {
    function get_table($string)
    {
        return str(class_basename($string))->replace('-', '_')->snake()->plural()->value();
    }
}

if (!function_exists('get_model')) {
    function get_model($string)
    {
        return "App\\Models\\" .  str($string)->studly()->singular();
    }
}

if (!function_exists('auth_patient')) {
    function auth_patient(): ?\App\Models\Patient
    {
        return auth()->guard('patient')->user();
    }
}
if (!function_exists('auth_dermatologist')) {
    function auth_dermatologist(): ?\App\Models\Dermatologist
    {
        return auth()->guard('dermatologist')->user();
    }
}

if (!function_exists('current_user')) {
    function current_user()
    {
        return auth_patient() ?? auth_dermatologist();
    }
}

if (!function_exists('generate_code')) {
    function generate_code($digits = 5)
    {
        return fake()->randomNumber($digits, true);
    }
}

if (!function_exists('date_hour_ar')) {
    function date_hour_ar($date)
    {
        return $date ? Carbon::parse($date)->locale(app()->getLocale())->isoFormat('dddd, Do MMMM YYYY, H:mm') : null;
    }
}

if (!function_exists('date_ar')) {
    function date_ar($date)
    {
        return $date ? Carbon::parse($date)->locale(app()->getLocale())->isoFormat('dddd, Do MMMM YYYY') : null;
    }
}

if (!function_exists('check_email')) {
    function check_email($mail)
    {
        return $mail instanceof SentMessage ? 'success' : 'failed';;
    }
}

if (!function_exists('localize_array')) {
    function localize_array($attributes)
    {
        $ar = array_map(fn ($l) => [$l => array_map(fn ($a) => $a . ' ' . __('main.in_' . $l), $attributes)], appLocales());
        $data = [];
        foreach ($ar as $item) {
            $key = array_keys($item)[0];
            $data[$key] = $item[$key];
        }
        return $data;
    }
}

if (!function_exists('isAr')) {
    function isAr()
    {
        return app()->getLocale() == 'ar';
    }
}

if (!function_exists('appLocales')) {
    function appLocales()
    {
        return config('translatable.locales');
    }
}

if (!function_exists('fileIsImg')) {
    function fileIsImg($path)
    {
        return in_array(pathinfo($path, PATHINFO_EXTENSION), ['jpeg', 'png', 'jpg']);
    }
}

if (!function_exists('auth_admin')) {
    function auth_admin()
    {
        return auth()->guard('admin')->user();
    }
}

if (!function_exists('get_segment')) {
    function get_segment($path, $segment = 1)
    {
        return $path ? explode("/", parse_url($path, PHP_URL_PATH))[$segment] : null;
    }
}
