<?php

namespace App\Models;

use App\Enums\ConsultationStatus;
use App\Http\Resources\Mobile\ConsultationImageResource;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\Crypt;

class Consultation extends Model
{
    use HasFactory, SoftDeletes;

    // protected $casts = [
    //     'status' => ConsultationStatus::class,
    // ];

    protected $fillable = [
        'dermatologist_id',
        'patient_id',
        'status',
        'description',
    ];

    public function dermatologist()
    {
        return $this->belongsTo(Dermatologist::class)->withTrashed();
    }

    public function patient()
    {
        return $this->belongsTo(Patient::class)->withTrashed();
    }

    public function consultationRate()
    {
        return $this->hasOne(ConsultationRate::class);
    }

    public function images()
    {
        return $this->hasMany(ConsultationImage::class);
    }

    public function scopeOpen($query)
    {
        return $query->where('status', ConsultationStatus::Open);
    }

    public function scopeNew($query)
    {
        return $query->where('status', ConsultationStatus::New);
    }

    public function scopeClosed($query)
    {
        return $query->where('status', ConsultationStatus::Closed);
    }

    public function scopeCanceled($query)
    {
        return $query->where('status', ConsultationStatus::Canceled);
    }

    public function getAllImagesAttribute()
    {
        return ConsultationImageResource::collection($this->images)->resolve();
    }
}
