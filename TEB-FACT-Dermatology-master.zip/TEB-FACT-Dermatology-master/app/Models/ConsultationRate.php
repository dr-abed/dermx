<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ConsultationRate extends Model
{
    use HasFactory , SoftDeletes;

    protected $fillable = [
        'consultation_id',
        'rate',
        'comment',
    ];

    public function consultation()
    {
        return $this->belongsTo(Consultation::class);
    }
}
