<?php

namespace App\Models;

use App\Models\TranslationModel;

class EmailTemplate extends TranslationModel
{

    protected $with = ['translations'];
    public $translatedAttributes = [
        'template_name', 'subject', 'body'
    ];

    public function getBody(...$model)
    {
        $vars = [];
        switch ($this->type) {
            case 'reply_contact_message':
                [$message] = [...$model];
                $vars = [
                    '{%message%}' => $message
                ];
                break;
        }
        return str_replace(array_keys($vars), array_values($vars), $this->body);
    }
}
