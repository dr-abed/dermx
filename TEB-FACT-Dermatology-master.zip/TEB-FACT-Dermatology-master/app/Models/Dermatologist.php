<?php

namespace App\Models;

use App\Enums\DermatologistProfileStatus;
use App\Enums\GenderType;
use App\Exceptions\DeleteParentException;
use App\Traits\HasEmail;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Carbon\Carbon;

class Dermatologist extends Authenticatable implements HasMedia
{
    use HasFactory, Notifiable, SoftDeletes, HasApiTokens, InteractsWithMedia, HasEmail;

    protected $guard = 'dermatologist';
    public static $IMGS = ['profile_image', 'university_certificate_image'];

    protected $fillable = [
        'full_name',
        'email',
        'username',
        'address',
        'gender',
        'mobile_number',
        'date_of_birth',
        'national_id_number',
        'description',
        'profile_status',
        'password',
        'facebook_id',
        'google_id',
        'medical_specialty',
        'experience_years',
        'graduation_year'
    ];

    protected $hidden = [
        'password',
        'remember_token',
        'mobile_verify_code',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'profile_status' => DermatologistProfileStatus::class,
        'gender' => GenderType::class,
    ];

    public static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            $model->email_verified_at = Carbon::now();
            $model->profile_status = DermatologistProfileStatus::InComplete;
        });
        self::deleting(function ($model) {
            $children[] = $model->consultations()->open()->count() ? __('main.consultations') : null;
            if ($c = array_filter($children)) {
                throw new DeleteParentException(implode(', ', $c));
            }
        });
    }

    // Generate media from base64
    public function generateMedia($images)
    {
        return collect($images)
            ->filter(fn ($image, $name) => $image && in_array($name, static::$IMGS))
            ->map(
                fn ($image, $name) =>
                $this->clearMediaCollection($name)
                    ->addMediaFromBase64($image)
                    ->usingFileName(str()->random(40) . '.' . 'jpg')
                    ->toMediaCollection($name)
            )
            ->toArray();
    }

    /*
        Accessors
    */

    public function getRemainingConsultationsCountAttribute()
    {
        return $this->maximum_no_of_open_consultations - $this->consultations()->open()->count();
    }

    public function getProfileImageAttribute()
    {
        return $this->getFirstMediaUrl('profile_image', 'image') ?: asset('imgs/default.svg');
    }

    public function getUniversityCertificateImageAttribute()
    {
        return $this->getFirstMediaUrl('university_certificate_image', 'image') ?: null;
    }

    public function getUniversityCertificateFileNameAttribute()
    {
        return $this->getFirstMedia('university_certificate_image') ? $this->getFirstMedia('university_certificate_image')->file_name : null;
    }

    public function getConsultationsCountAttribute()
    {
        return $this->consultations()->count();
    }

    public function getLastConsultationDateAttribute()
    {
        return $this->consultations()->latest()->first()->created_at ?? null;
    }

    public function getRatingAttribute()
    {
        return round($this->consultationsRates()->avg('rate'), 1) ?? 0;
    }

    public function getRatingCountAttribute()
    {
        return $this->consultationsRates()->count();
    }

    public function routeNotificationForFcm()
    {
        return $this->fcm_token ?? '';
    }

    /*
        Scopes
    */

    public function scopeActive($query)
    {
        return $query->whereIn('profile_status', [
            DermatologistProfileStatus::NotApproved,
            DermatologistProfileStatus::Approved,
        ]);
    }

    /*
        Relations
    */

    public function consultations()
    {
        return $this->hasMany(Consultation::class);
    }

    public function consultationsRates()
    {
        //get the consultations rates belongs to the consultations belongs to the dermatologist
        return $this->hasManyThrough(ConsultationRate::class, Consultation::class);
    }

    public function articles()
    {
        return $this->hasMany(Article::class);
    }
}
