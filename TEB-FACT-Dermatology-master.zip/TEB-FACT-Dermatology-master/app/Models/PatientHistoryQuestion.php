<?php

namespace App\Models;

use App\Enums\PatientHistoryQuestionType;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PatientHistoryQuestion extends TranslationModel
{
    use HasFactory, SoftDeletes;

    protected $translationForeignKey = 'phq_id';
    protected $with = ['translations'];
    public $translatedAttributes = ['question', 'options'];
    protected $fillable = ['type', 'question', 'options'];
    protected $casts = ['type' => PatientHistoryQuestionType::class, 'options' => 'array'];
    public function history()
    {
        return $this->hasOne(PatientHistory::class);
    }
}
