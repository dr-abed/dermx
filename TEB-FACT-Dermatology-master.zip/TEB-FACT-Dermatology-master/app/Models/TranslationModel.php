<?php

namespace App\Models;

use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Astrotomic\Translatable\Contracts\Translatable as TranslatableContract;
use Illuminate\Database\Eloquent\Model;

class TranslationModel extends Model implements TranslatableContract
{
    use HasFactory;
    use Translatable;

    public function scopeJoinTranslation($q, $table = null, $translation_table = null, $foreign_key = null, $id = 'id')
    {
      $table ??= with(new static)->getTable();
      $translation_table ??= str($table)->singular() . "_translations";
      $foreign_key ??= str($table)->singular() . "_id";

      return $q->leftJoin("$translation_table", "$table.$id", "=", "$translation_table.$foreign_key")
        ->where("$translation_table.locale", app()->getLocale());
    }
}
