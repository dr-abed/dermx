<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Page extends TranslationModel implements HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia;

    public static $IMGS = ['icon'];
    public $translatedAttributes = ['title', 'description'];
    protected $fillable = ['slug', 'title', 'description', 'icon'];
    protected $with = ['translations'];

    // Generate media from base64
    public function generateMedia($images)
    {
        return collect($images)
            ->filter(fn ($image, $name) => $image && in_array($name, static::$IMGS))
            ->map(
                fn ($image, $name) =>
                $this->clearMediaCollection($name)
                    ->addMediaFromBase64($image)
                    ->usingFileName(str()->random(40) . '.' . 'jpg')
                    ->toMediaCollection($name)
            )
            ->toArray();
    }

    public function getIconAttribute()
    {
        return $this->getFirstMediaUrl('icon') ?: asset('imgs/default.svg');
    }

    public function scopeActive($query)
    {
        return $query->where('status', true);
    }
}
