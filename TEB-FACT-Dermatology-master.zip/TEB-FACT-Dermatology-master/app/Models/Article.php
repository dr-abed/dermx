<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Article extends TranslationModel implements HasMedia
{
    use HasFactory, SoftDeletes, InteractsWithMedia;

    public static $IMGS = ['image'];
    public $translatedAttributes = ['title', 'description'];
    protected $fillable = ['title', 'description', 'image'];
    protected $with = ['translations'];

    // Generate media from base64
    public function generateMedia($images)
    {
        return collect($images)
            ->filter(fn ($image, $name) => $image && in_array($name, static::$IMGS))
            ->map(
                fn ($image, $name) =>
                $this->clearMediaCollection($name)
                    ->addMediaFromBase64($image)
                    ->usingFileName(str()->random(40) . '.' . 'jpg')
                    ->toMediaCollection($name)
            )
            ->toArray();
    }

    public function getImageAttribute()
    {
        //TODO: REMOVE THIS ON PRODUCTION
        if ($this->getFirstMediaUrl('image') == null || $this->getFirstMediaUrl('image') == '') {
            return match ($this->id) {
                1 => 'https://cdn.altibbi.com/cdn/cache/1000x500/image/2021/03/26/024e26dee63aa17222bd0df840acef07.png.webp',
                2 => 'https://aquatherapy.store/wp-content/uploads/2022/01/skin-type.jpg',
                3 => 'https://cdn.salla.sa/rRjZy/tSlzdYi8hMGinjhziOiHuBPDTnhjbvnRvweGNvdG.jpg',
                4 => 'https://raqyi.com/wp-content/uploads/2017/03/5-%D8%AE%D8%B7%D9%88%D8%A7%D8%AA-%D9%85%D9%86-%D8%A3%D8%AC%D9%84-%D8%A7%D9%84%D8%B9%D9%86%D8%A7%D9%8A%D8%A9-%D8%A8%D8%A7%D9%84%D8%A8%D8%B4%D8%B1%D8%A9-%D9%84%D9%84%D8%B1%D8%AC%D8%A7%D9%84-%D9%88%D8%A7%D9%84%D8%AD%D8%B5%D9%88%D9%84-%D8%B9%D9%84%D9%89-%D9%88%D8%AC%D9%87-%D9%85%D8%AA%D8%A3%D9%84%D9%82.jpg',
                5 => 'https://www.aljazeera.net/wp-content/uploads/2018/05/ecc668e2-f284-4b78-b458-8e3969b7f30e.jpeg?resize=686%2C513&quality=80',
            };
        } else {
            return  $this->getFirstMediaUrl('image');
        }
    }

    public function getNumberOfViewsAttribute()
    {
        return $this->visits()->count();
    }

    public function dermatologist()
    {
        return $this->belongsTo(Dermatologist::class);
    }

    public function visits()
    {
        return $this->hasMany(Visit::class);
    }
}
