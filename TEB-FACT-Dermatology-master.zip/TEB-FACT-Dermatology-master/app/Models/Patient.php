<?php

namespace App\Models;

use App\Enums\GenderType;
use App\Traits\HasEmail;
use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Carbon\Carbon;

class Patient extends Authenticatable implements HasMedia
{
    use HasFactory, Notifiable, HasApiTokens, SoftDeletes, InteractsWithMedia, HasEmail;

    public static function boot()
    {
        parent::boot();
        static::creating(function ($model) {
            $model->email_verified_at = Carbon::now();
        });
    }

    public static $IMGS = ['profile_image'];
    protected $guard = 'patient';
    protected $guarded = [];


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
        'mobile_verify_code',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'gender' => GenderType::class,
    ];

    // Generate media from base64
    public function generateMedia($images)
    {
        return collect($images)
            ->filter(fn ($image, $name) => $image && in_array($name, static::$IMGS))
            ->map(
                fn ($image, $name) =>
                $this->clearMediaCollection($name)
                    ->addMediaFromBase64($image)
                    ->usingFileName(str()->random(40) . '.' . 'jpg')
                    ->toMediaCollection($name)
            )
            ->toArray();
    }

    /*
        Relations
    */

    public function patientHistories()
    {
        return $this->hasMany(PatientHistory::class);
    }

    public function consultations()
    {
        return $this->hasMany(Consultation::class);
    }

    public function consultationRates()
    {
        return $this->hasMany(ConsultationRate::class);
    }

    /*
        Attributes
    */

    public function getProfileImageAttribute()
    {
        return $this->getFirstMediaUrl('profile_image') ?: asset('imgs/default.svg');
    }

    public function getOpenConsultationsAttribute()
    {
        return $this->consultations()->open()->count();
    }

    public function getConsultationsCountAttribute()
    {
        return $this->consultations()->count();
    }

    public function getIsHistoryCompletedAttribute()
    {
        //check if patient answered all patient histories
        $nullPatientHistories = $this->patientHistories->where('answer', null)->count();
        if ($nullPatientHistories > 0) {
            return false;
        }
        return true;
    }

    public function routeNotificationForFcm()
    {
        return $this->fcm_token ?? '';
    }
}
