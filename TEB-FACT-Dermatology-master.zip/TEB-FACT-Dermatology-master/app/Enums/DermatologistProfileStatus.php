<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static NotVerified()
 * @method static static InComplete()
 * @method static static NotApproved()
 * @method static static Approved()
 */
final class DermatologistProfileStatus extends Enum
{
    const NotVerified = 0;
    const InComplete = 1;
    const NotApproved = 2;
    const Approved = 3;

    public function __construct($enumValue)
    {
        parent::__construct($enumValue);
    }

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::NotVerified:
                return __('main.DermatologistProfileStatus.notVerified');
            case self::InComplete:
                return __('main.DermatologistProfileStatus.inComplete');
            case self::NotApproved:
                return __('main.DermatologistProfileStatus.notApproved');
            case self::Approved:
                return __('main.DermatologistProfileStatus.approved');
            default:
                return self::getDescription($value);
        }
    }
}
