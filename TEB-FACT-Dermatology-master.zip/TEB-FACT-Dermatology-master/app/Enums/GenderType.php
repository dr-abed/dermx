<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static Male()
 * @method static static Female()
 */
final class GenderType extends Enum
{
    const Male = 'male';
    const Female = 'female';

    public function __construct($enumValue)
    {
        parent::__construct($enumValue);
    }

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::Male:
                return __('main.GenderType.male');
            case self::Female:
                return __('main.GenderType.female');
            default:
                return self::getDescription($value);
        }
    }
}
