<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static Textarea()
 * @method static static Radio()
 * @method static static TrueFalse()
 * @method static static Checkbox()
 */
final class PatientHistoryQuestionType extends Enum
{
    const Textarea = 0;
    const Radio = 1;
    const TrueFalse = 2;
    const Checkbox = 3;

    public function __construct($enumValue)
    {
        parent::__construct($enumValue);
    }

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::Textarea:
                return __('main.PatientHistoryQuestionType.textarea');
            case self::Radio:
                return __('main.PatientHistoryQuestionType.radio');
            case self::TrueFalse:
                return __('main.PatientHistoryQuestionType.trueFalse');
            case self::Checkbox:
                return __('main.PatientHistoryQuestionType.checkbox');
            default:
                return self::getDescription($value);
        }
    }
}
