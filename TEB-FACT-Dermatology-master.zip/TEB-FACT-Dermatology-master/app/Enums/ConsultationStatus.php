<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static New()
 * @method static static Open()
 * @method static static Closed()
 * @method static static Canceled()
 */
final class ConsultationStatus extends Enum
{
    const New = 1;
    const Open = 2;
    const Closed = 3;
    const Canceled = 4;


    public function __construct($enumValue)
    {
        parent::__construct($enumValue);
    }

    public static function getDescription($value): string
    {
        switch ($value) {
            case self::New:
                return __('main.ConsultationStatus.new');
            case self::Open:
                return __('main.ConsultationStatus.open');
            case self::Closed:
                return __('main.ConsultationStatus.closed');
            case self::Canceled:
              return __('main.ConsultationStatus.canceled');
            default:
                return self::getDescription($value);
        }
    }
}
