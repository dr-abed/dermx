<?php declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static Consultation()
 * @method static static Article()
 */
final class NotificationClickAction extends Enum
{
    const Consultation = 0;
    const Article = 1;
}
