<?php

namespace App\Exceptions;

use Exception;

class DeleteParentException extends Exception
{
}
