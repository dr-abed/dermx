<?php

namespace App\Notifications\Mobile;

use App\Enums\ConsultationStatus;
use Illuminate\Bus\Queueable;
use App\Enums\NotificationClickAction;
use NotificationChannels\Fcm\FcmChannel;
use NotificationChannels\Fcm\FcmMessage;
use Illuminate\Notifications\Notification;
use NotificationChannels\Fcm\Resources\Notification as FirebaseNotification;

class GlobalNotification extends Notification
{
    use Queueable;

    protected $message;
    protected $consultation_room_id;


    public function __construct($message, $consultation_room_id)
    {
        $this->message = $message;
        $this->consultation_room_id = $consultation_room_id;
    }

    public function via($notifiable)
    {
        return ['database', FcmChannel::class];
    }

    public function toArray($notifiable)
    {
        $data = $this->data();
        return [
            'title'         => $data['title'],
            'body'          => $data['body'],
            'target_id'     => $data['target_id'],
            'click_action'  => $data['click_action'],
        ];
    }

    public function toFcm($notifiable)
    {
        $data = $this->data();
        $additionalData = [
            'target_id'    => $data['target_id'],
            'click_action' => $data['click_action'],
        ];

        return FcmMessage::create()
            ->setData(array_map('strval', $additionalData))
            ->setNotification(FirebaseNotification::create()
                ->setTitle($data['titleText'])
                ->setBody($data['bodyText'])
                // ->setImage('https://images.ctfassets.net/hrltx12pl8hq/3j5RylRv1ZdswxcBaMi0y7/b84fa97296bd2350db6ea194c0dce7db/Music_Icon.jpg')
            );
    }

    public function data()
    {
        $title = ('messages.received_new_message');
        $body = $this->message;
        return [
            'title' => $title,
            'titleText' => __($title),
            'body' => $body,
            'bodyText' => __($body),
            'target_id' => $this->consultation_room_id,
            'click_action' => NotificationClickAction::Consultation,
        ];
    }

}
