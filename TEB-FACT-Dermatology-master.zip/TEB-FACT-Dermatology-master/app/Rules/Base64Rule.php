<?php

namespace App\Rules;

use Symfony\Component\HttpFoundation\File\File;
use Illuminate\Contracts\Validation\InvokableRule;
use Illuminate\Contracts\Validation\ValidatorAwareRule;

class Base64Rule implements InvokableRule, ValidatorAwareRule
{
    protected $validator;

    public function __construct(public $max)
    {
    }

    /**
     * Run the validation rule.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     * @return void
     */
    public function __invoke($attribute, $value, $fail)
    {
        if (!empty($value)) {
            $file = $this->convertToFile($value);

            $img = $this->validator->validateImage($attribute, $file);
            if (!$img) {
                return $fail(__('validation.image'));
            }

            $max = $this->validator->validateMax($attribute, $file, [$this->max]);
            if (!$max) {
                return $fail(__('validation.max.file',  ['max' => $this->max]));
            }
        }

        return true;
    }

    /**
     * Set the current validator.
     *
     * @param  \Illuminate\Validation\Validator  $validator
     * @return $this
     */
    public function setValidator($validator)
    {
        $this->validator = $validator;

        return $this;
    }

    protected function convertToFile(string $value): File
    {
        if (strpos($value, ';base64') !== false) {
            [, $value] = explode(';', $value);
            [, $value] = explode(',', $value);
        }

        $binaryData = base64_decode($value);
        $tmpFile = tempnam(sys_get_temp_dir(), 'base64validator');

        file_put_contents($tmpFile, $binaryData);

        return new File($tmpFile);
    }

}
