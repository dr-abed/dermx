<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ContactMessageMail extends Mailable
{
    use Queueable, SerializesModels;

    public $template;
    public $body;

    public function __construct($template, $body)
    {
        $this->template = $template;
        $this->body = $body;
    }

    public function build()
    {
        return $this->subject($this->template->subject)->markdown('emails.template', [
            'body' => $this->body,
        ]);
    }
}
