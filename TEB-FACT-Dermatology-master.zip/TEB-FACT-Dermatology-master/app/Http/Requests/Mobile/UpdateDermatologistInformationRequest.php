<?php

namespace App\Http\Requests\Mobile;

use App\Rules\Base64Rule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateDermatologistInformationRequest extends FormRequest
{
    public function rules()
    {
        return [
            'medical_specialty' => ['required', 'string', 'max:255'],
            'experience_years' => ['required', 'numeric', 'min:1', 'max:60'],
            'graduation_year' => ['required', 'numeric'],
            'university_certificate_image' => ['nullable', new Base64Rule(8192)],
        ];
    }
}
