<?php

namespace App\Http\Requests\Mobile;

use App\Rules\Base64Rule;
use Illuminate\Foundation\Http\FormRequest;

class ConsultationRequest extends FormRequest
{
    public function rules()
    {
        return [
            'images' => 'required',
            'notes' => 'required',
        ];
    }
}
