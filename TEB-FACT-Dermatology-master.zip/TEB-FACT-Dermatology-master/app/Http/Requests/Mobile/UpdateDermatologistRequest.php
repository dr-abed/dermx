<?php

namespace App\Http\Requests\Mobile;

use App\Enums\GenderType;
use App\Rules\Base64Rule;
use BenSampo\Enum\Rules\EnumValue;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateDermatologistRequest extends FormRequest
{
    public function rules()
    {
        return [
            'full_name' => 'nullable|string',
            'email' => ['nullable', 'string', 'email', Rule::unique('dermatologists', 'email')->ignore($this->user('dermatologist'))->withoutTrashed()],
            'mobile_number' => ['nullable', 'string', Rule::unique('dermatologists', 'mobile_number')->ignore($this->user('dermatologist'))->withoutTrashed()],
            'date_of_birth' => 'nullable|date|before:today',
            'profile_image' => ['nullable', new Base64Rule(8192)],
            'gender' => ['nullable',  new EnumValue(GenderType::class, false)],
            'locale' => 'sometimes|string|in:' . implode(',', appLocales()),
        ];
    }
}
