<?php

namespace App\Http\Requests\Mobile;

use App\Enums\GenderType;
use Illuminate\Foundation\Http\FormRequest;
use BenSampo\Enum\Rules\EnumValue;
use App\Rules\Base64Rule;
use Illuminate\Validation\Rule;

class StoreDermatologistRequest extends FormRequest
{
    public function rules()
    {
        return [
            'full_name' => 'required|string',
            'email' => ['required', 'string', 'email', 'max:255', Rule::unique('dermatologists', 'email')->withoutTrashed()],
            'password' => 'required|string|confirmed',
            'mobile_number' => ['required', 'string', 'max:255', Rule::unique('dermatologists', 'mobile_number')->withoutTrashed()],
            'date_of_birth' => 'required|date|before:today',
            'gender' => ['required',  new EnumValue(GenderType::class, false)],
            'locale' => 'required|string|in:' . implode(',', appLocales()),
        ];
    }
}
