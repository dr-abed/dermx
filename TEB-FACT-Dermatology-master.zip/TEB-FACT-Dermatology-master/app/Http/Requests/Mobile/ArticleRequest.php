<?php

namespace App\Http\Requests\Mobile;

use App\Rules\Base64Rule;
use Astrotomic\Translatable\Validation\RuleFactory;
use Illuminate\Foundation\Http\FormRequest;

class ArticleRequest extends FormRequest
{
    public function rules()
    {
        return  RuleFactory::make([
            '%title%' => 'required|string',
            '%description%' => 'required|string',
            'image' => ['nullable', new Base64Rule(8192)]
        ]);
    }
}
