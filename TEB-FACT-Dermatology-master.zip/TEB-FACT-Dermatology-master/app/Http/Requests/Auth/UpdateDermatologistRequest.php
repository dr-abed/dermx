<?php

namespace App\Http\Requests\Auth;

use App\Enums\DermatologistProfileStatus;
use App\Enums\GenderType;
use App\Rules\Base64Rule;
use BenSampo\Enum\Rules\EnumValue;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateDermatologistRequest extends FormRequest
{
    public function rules()
    {
        return [
            'full_name' => 'nullable|string',
            'email' => ['nullable', 'string', 'email', Rule::unique('dermatologists', 'email')->ignore($this->dermatologist)->withoutTrashed()],
            'mobile_number' => ['nullable', 'string', Rule::unique('dermatologists', 'mobile_number')->ignore($this->dermatologist)->withoutTrashed()],
            'date_of_birth' => 'nullable|date|before:today',
            'profile_image' => ['nullable', new Base64Rule(8192)],
            'gender' => ['nullable',  new EnumValue(GenderType::class, false)],
            'locale' => 'sometimes|string|in:' . implode(',', appLocales()),
            'maximum_no_of_open_consultations' => 'nullable|integer|min:5',
            'medical_specialty' => ['nullable', 'string', 'max:255'],
            'experience_years' => ['nullable', 'numeric', 'min:1', 'max:60'],
            'university_certificate_image' => ['nullable', new Base64Rule(8192)],
            'profile_status' => ['nullable', new EnumValue(DermatologistProfileStatus::class, false)],
            'graduation_year' => 'nullable|integer',
        ];
    }
}
