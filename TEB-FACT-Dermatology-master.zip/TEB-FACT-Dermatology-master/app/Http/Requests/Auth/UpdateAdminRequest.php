<?php

namespace App\Http\Requests\Auth;

use App\Enums\GenderType;
use Illuminate\Foundation\Http\FormRequest;
use BenSampo\Enum\Rules\EnumValue;
use App\Rules\Base64Rule;
use Illuminate\Validation\Rule;

class UpdateAdminRequest extends FormRequest
{
    public function rules()
    {
        return [
            'full_name' => 'nullable|string',
            'email' => ['nullable','string','email',Rule::unique('admins','email')->ignore($this->admin)->withoutTrashed()],
            'mobile_number' => ['nullable','string',Rule::unique('admins','mobile_number')->ignore($this->admin)->withoutTrashed()],
            'date_of_birth' => 'nullable|date|before:today',
            'profile_image' => ['nullable', new Base64Rule(8192)],
            'gender' => ['nullable',  new EnumValue(GenderType::class, false)],
            'locale' => 'sometimes|string|in:'. implode(',', appLocales()),
        ];
    }
}
