<?php

namespace App\Http\Requests\Auth;

use App\Models\BaseModel;
use Illuminate\Foundation\Http\FormRequest;

class SocialiteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        $user_type = request()->user_type;
        $valid_user_types = ['dermatologist', 'patient'];
        if (!in_array($user_type, $valid_user_types)) {
            return [
                'user_type' => ['required', 'string', 'in:dermatologist,patient'],
            ];
        }
        return [
            'user_type' => ['required', 'string', 'in:dermatologist,patient'],
            'provider' => ['required', 'string', 'in:google,facebook'],
            'access_provider_token' => ['required', 'string']
        ];
    }
}
