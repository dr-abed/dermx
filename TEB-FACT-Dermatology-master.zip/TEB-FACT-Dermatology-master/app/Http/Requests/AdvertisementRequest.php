<?php

namespace App\Http\Requests;

use Astrotomic\Translatable\Validation\RuleFactory;
use Illuminate\Foundation\Http\FormRequest;
use App\Rules\Base64Rule;

class AdvertisementRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'status' => ['required', 'boolean'],
            'link' => ['nullable', 'url'],
            'image' => ['required', new Base64Rule(8192)],
        ];
    }
}
