<?php

namespace App\Http\Requests;

use BenSampo\Enum\Rules\EnumValue;
use App\Enums\PatientHistoryQuestionType;
use Astrotomic\Translatable\Validation\RuleFactory;
use Illuminate\Foundation\Http\FormRequest;


class PatientHistoryQuestionRequest extends FormRequest
{
    public function rules(): array
    {
        return RuleFactory::make([
            'type' => ['required', 'integer', new EnumValue(PatientHistoryQuestionType::class, false)],
            '%question%' => 'required|string',
            '%options%' => 'array|required_if:type,' . PatientHistoryQuestionType::Radio . ',' . PatientHistoryQuestionType::Checkbox,
        ]);
    }
}
