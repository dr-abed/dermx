<?php

namespace App\Http\Requests;

use Astrotomic\Translatable\Validation\RuleFactory;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use App\Rules\Base64Rule;

class PageRequest extends FormRequest
{
    public function rules(): array
    {
        return RuleFactory::make([
            '%title%' => 'required|string',
            'status' => 'required|boolean',
            'slug' => ['nullable', 'string', Rule::unique('page_translations', 'title')->where('locale', 'en')->ignore($this->page?->id, 'page_id')],
            '%description%' => 'required|string',
            'icon' => ['nullable', new Base64Rule(8192)],
        ]);
    }
}
