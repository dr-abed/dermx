<?php

namespace App\Http\Controllers\API\Mobile\Patient;

use App\Enums\ConsultationStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Mobile\ConsultationRequest;
use App\Http\Resources\Mobile\ConsultationResource;
use App\Models\BaseModel;
use App\Models\Consultation;
use App\Models\Dermatologist;
use App\Models\Patient;
use App\Notifications\Mobile\ConsultationNotification;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class ConsultationController extends Controller
{
    use HTTPResponses;
    public function index(Request $request)
    {
        $request->validate([
            'status' => 'nullable|in:' . implode(',', ConsultationStatus::getValues()),
        ]);
        $consultations = $request->user('patient')
            ->consultations()->with('dermatologist', 'consultationRate')
            ->when($request->status, fn ($query) => $query->where('status', $request->status))
            ->orderBy('updated_at', 'desc')
            ->paginate($this->paginate($request));
        return $this->successResponse(['consultations' => ConsultationResource::collection($consultations)], __('messages.retrived', ['message' => __('main.consultations')]), 200);
    }

    public function store(ConsultationRequest $request)
    {
        $patient = $request->user('patient');
        //check if patient answered all patient histories
        if (!$patient->is_history_completed) {
            return $this->errorResponse(null, __('main.patient_histories_not_answered'), 422);
        }
        $images = $request->validated()['images'];
        $consultation = $patient->consultations()->create($request->safe()->except('images'));
        $consultation->notes = decryptData($request->notes);
        foreach ($images as $image) {
            $image = decryptData($image);
            $consultation->images()->create()->generateMedia(['image' => $image]);
        }
        $consultation->status = ConsultationStatus::New;
        $consultation->save();
        try {
            if ($patient->fcm_token) {
                $patient->notify(new ConsultationNotification($consultation));
            }
        } catch (\Throwable $th) {
            //throw $th;
        }
        return $this->successResponse(null, __('messages.created', ['message' => __('main.consultation')]), 201);
    }

    public function rate(Request $request, Consultation $consultation)
    {
        $request->validate([
            'rate' => 'required|numeric|min:1|max:5',
            'comment' => 'nullable|string'
        ]);

        abort_if($consultation->patient_id != request()->user('patient')->id, 403, __('main.not_allowed'));
        abort_if($consultation->status != ConsultationStatus::Closed, 403, __('main.consultation_not_closed'));
        abort_if($consultation->consultationRate()->exists(), 403, __('main.consultation_already_rated'));
        $consultation->consultationRate()->create($request->all());
        return $this->successResponse(null, __('messages.created', ['message' => __('main.consultation_rate')]), 201);
    }

    public function cancel(Consultation $consultation)
    {
        abort_if($consultation->patient_id != request()->user('patient')->id, 403, __('main.not_allowed'));
        abort_if($consultation->status != ConsultationStatus::New, 403, __('main.consultation_not_new'));
        $consultation->update(['status' => ConsultationStatus::Canceled]);
        try {
            $consultation->patient->notify(new ConsultationNotification($consultation));
        } catch (\Throwable $th) {
            //throw $th;
        }
        return $this->successResponse(null, __('messages.cancelled', ['message' => __('main.consultation')]), 200);
    }
}
