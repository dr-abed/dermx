<?php

namespace App\Http\Controllers\API\Mobile\Patient;

use App\Traits\HTTPResponses;
use App\Http\Controllers\Controller;
use App\Http\Requests\Mobile\StorePatientRequest;
use App\Http\Requests\Mobile\UpdatePatientRequest;
use App\Http\Resources\PatientResource;
use App\Models\BaseModel;
use App\Models\Patient;
use App\Models\PatientHistory;
use App\Models\PatientHistoryQuestion;
use App\Traits\AuthProcessing;
use App\Traits\Loggable;
use App\Traits\ThrottlesLogins;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Laravel\Socialite\Facades\Socialite;

class PatientController extends Controller
{
    use ThrottlesLogins, Loggable, AuthProcessing, HTTPResponses;

    private $guard = 'patient';
    private $maxAttempts = 50000000000000;
    private $decayMinutes = 180;

    public function register(StorePatientRequest $request)
    {
        $patient = Patient::create($request->safe()->except('profile_image'));
        $patient->update(['password' => bcrypt($request->password)]);
        // make history with no answers
        $questions = PatientHistoryQuestion::all();
        $questions->each(function ($question) use ($patient) {
            PatientHistory::create([
                'patient_id' => $patient->id,
                'question_id' => $question->id,
            ]);
        });

        return response()->json($this->getUser($patient), 200);
    }

    public function changePassword(Request $request)
    {
        $request->validate([
            'old_password' => 'required',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = $request->user('patient');
        if (!Hash::check($request->old_password, $user->password)) {
            throw ValidationException::withMessages([
                'old_password'  => __('auth.password')
            ]);
        }

        $user->update(['password' => bcrypt($request->password)]);

        return response()->json(['message' => __('auth.password-reset')], 200);
    }

    public function logout(Request $request)
    {
        $request->user('patient')->token()->revoke();
        $request->user('patient')->update(['fcm_token' => null]);
        return response()->json(['message' => __('auth.logged-out')], 200);
    }

    public function getUser($user)
    {
        return [
            'token' => $user->createToken('patient', ['patient'])->accessToken,
            'patient' => PatientResource::make($user),
        ];
    }

    private function guard()
    {
        return Auth::guard('patient');
    }

    public function update(UpdatePatientRequest $request)
    {
        $patient = $request->user('patient');
        $patient->update($request->safe()->except('profile_image'));
        if ($request->has('profile_image')) {
            $patient->generateMedia(['profile_image' => $request->profile_image]);
        }
        return $this->successResponse(['patient' => PatientResource::make($patient)], __('messages.updated', ['message' => __('main.patient')]), 200);
    }

    public function profile(Request $request)
    {
        $patient = $request->user('patient');
        return $this->successResponse(['patient' => PatientResource::make($patient)], __('messages.retrived', ['message' => __('main.patient')]), 200);
    }

    public function destroy(Request $request)
    {
        $request->user('patient')->tokens()->update(['revoked' => true]);
        $request->user('patient')->update(['fcm_token' => null]);
        $request->user('patient')->delete();

        return $this->successResponse(null, __('messages.deleted', ['message' => __('main.patient')]), 200);
    }

    public function sendEmailVerification(Request $request)
    {
        $patient = $request->user('patient');
        if ($patient) {
            $verify_pin = DB::table('password_resets')->where('email', $patient->email)->where('user_type', BaseModel::PATIENT)->where('pin_type', 'email_verification');
            if ($verify_pin->exists()) {
                $verify_pin->delete();
            }
            $this->sendVerificationPINEmail($patient);
        }
        return $this->successResponse(null, __('auth.pin-code-send'), 200);
    }

    public function verifyEmail(Request $request)
    {
        $request->validate([
            'pin' => 'required|numeric|digits:6',
        ]);
        $patient = $request->user('patient');
        if ($patient) {
            $verify_pin = DB::table('password_resets')->where('email', $patient->email)->where('user_type', BaseModel::PATIENT)->where('pin_type', 'email_verification')->where('pin', $request->pin);
            if ($verify_pin->exists()) {
                $verify_pin->delete();
                $patient->update(['email_verified_at' => now()]);
                return $this->successResponse(null, __('auth.email-verified'), 200);
            }
        }
        return $this->errorResponse(null,__('auth.invalid-pin'), 422);
    }

    public function sendForgotPasswordEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:patients,email',
        ]);
        $patient = Patient::where('email', $request->email)->first();
        if ($patient) {
            $verify_pin = DB::table('password_resets')->where('email', $patient->email)->where('user_type', BaseModel::PATIENT)->where('pin_type', 'forgot_password');
            if ($verify_pin->exists()) {
                $verify_pin->delete();
            }
            $this->sendForgotPasswordPINEmail($patient);
        }
        return $this->successResponse(null, __('auth.pin-code-send'), 200);
    }

    public function verifyForgotPassword(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:patients,email',
            'pin' => 'required|numeric|digits:6',
        ]);
        $patient = Patient::where('email', $request->email)->first();
        if ($patient) {
            $verify_pin = DB::table('password_resets')->where('email', $patient->email)->where('user_type', BaseModel::PATIENT)->where('pin_type', 'forgot_password')->where('pin', $request->pin);
            if ($verify_pin->exists()) {
                $verify_pin->delete();
                $token = $patient->createToken('patient', ['patient'])->accessToken;
                return $this->successResponse($token, __('auth.pin-verified'), 200);
            }
        }
        return $this->errorResponse(null,__('auth.invalid-pin'), 422);
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'password' => 'required|string|min:8|confirmed',
        ]);
        $patient = $request->user('patient');
        if ($patient) {
            $patient->update(['password' => bcrypt($request->password)]);
            $patient->tokens()->update(['revoked' => true]);
            return $this->successResponse(null, __('auth.password-reset'), 200);
        }
        return $this->errorResponse(null,__('auth.invalid-pin'), 422);
    }
}
