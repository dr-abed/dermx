<?php

namespace App\Http\Controllers\API\Mobile\Patient;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\Mobile\NotificationResource;
use App\Traits\HTTPResponses;

class NotificationController extends Controller
{
    use HTTPResponses;
    public function index(Request $request)
    {
        $notifications = $request->user('patient')->notifications()->latest()->paginate($this->paginate($request));
        return $this->successResponse([
            'notifications' => NotificationResource::collection($notifications),
        ], __('messages.retrived', ['message' => __('main.notifications')]), 200);
    }

    public function unseenCount(Request $request)
    {
        return $this->successResponse([
            'unseen_count' => $request->user('patient')->notifications()->where('seen', false)->count(),
        ], __('messages.retrived', ['message' => __('main.unseen_count')]), 200);
    }

    public function seen(Request $request)
    {
        $request->user('patient')->notifications()->update(['seen' => true]);
        return $this->successResponse(['unseen_count' => 0], __('messages.updated', ['message' => __('main.notifications')]), 200);
    }

    public function updateFcm(Request $request)
    {
        $request->validate(['fcm_token' => 'required']);
        $request->user('patient')->update(['fcm_token' => $request->fcm_token]);

        return $this->successResponse(null, __('messages.updated', ['message' => __('main.fcm_token')]), 200);
    }
}
