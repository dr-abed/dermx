<?php

namespace App\Http\Controllers\API\Mobile\Patient;

use App\Http\Controllers\Controller;
use App\Http\Resources\Mobile\PatientHistoryResource;
use App\Models\PatientHistory;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class PatientHistoryController extends Controller
{
    use HTTPResponses;

    public function index(Request $request)
    {
        $patientHistory = $request->user('patient')->patientHistories()->with('question')->get();
        return $this->successResponse(['patient_history' => PatientHistoryResource::collection($patientHistory)], __('messages.retrived', ['message' => __('main.patient_history')]), 200);
    }

    public function update(Request $request)
    {
        $array = [];
        if (is_array($request->all()) && count($request->all()) != 0) {
            $array = $request->all();
        }
        foreach ($array as $item) {
            if (
                !isset($item['id']) || !isset($item['answer']) ||
                empty($item['id']) || empty($item['answer']) ||
                $item['id'] == null || $item['answer'] == null
            ) {
                return $this->errorResponse(null, __('messages.missing_data'), 422);
            }
            PatientHistory::where('id', $item['id'])->update(['answer' => decryptData($item['answer'])]);
        }
        return $this->successResponse(null, __('messages.updated', ['message' => __('main.patient_history')]), 200);
    }
}
