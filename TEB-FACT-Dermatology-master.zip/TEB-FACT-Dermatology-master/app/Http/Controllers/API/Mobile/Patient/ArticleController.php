<?php

namespace App\Http\Controllers\API\Mobile\Patient;

use App\Http\Controllers\Controller;
use App\Http\Resources\Mobile\ArticleListResource;
use App\Http\Resources\Mobile\ArticleResource;
use App\Models\Article;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    use HTTPResponses;
    public function index(Request $request)
    {
        $articles = Article::query()
            ->with('translations', 'media', 'dermatologist')
            ->when($request->search, fn ($query, $search) => $query->whereTranslationLike('title', "%$search%"))
            ->latest()
            ->paginate($this->paginate($request));
        return $this->successResponse(['articles' => ArticleListResource::collection($articles)], __('messages.retrived', ['message' => __('main.articles')]), 200);
    }

    public function show(Article $article, Request $request)
    {
        $article->load('translations', 'media', 'dermatologist');
        $patient = $request->user('patient');
        // Increase views count but only once per patient
        if ($patient && !$article->visits()->where('patient_id', $patient->id)->exists()) {
            $article->visits()->create(['patient_id' => $patient->id]);
        }
        return $this->successResponse(['article' => ArticleResource::make($article)], __('messages.retrived', ['message' => __('main.article')]), 200);
    }
}
