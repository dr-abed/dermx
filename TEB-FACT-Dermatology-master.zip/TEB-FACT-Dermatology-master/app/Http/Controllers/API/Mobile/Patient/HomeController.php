<?php

namespace App\Http\Controllers\API\Mobile\Patient;

use App\Http\Controllers\Controller;
use App\Http\Resources\Mobile\ConsultationResource;
use App\Http\Resources\Mobile\AdvertisementResource;
use App\Http\Resources\Mobile\ArticleListResource;
use App\Models\Advertisement;
use App\Models\Article;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    use HTTPResponses;
    public function index(Request $request)
    {
        $advertisements = Advertisement::query()
            ->active()
            ->with('media')
            ->latest()
            ->get();

        $articles = Article::query()
            ->with('translations', 'media', 'dermatologist')
            ->limit(5)
            ->latest()
            ->get();

        $open_consultations = $request->user('patient')
            ->consultations()
            ->open()
            ->with('dermatologist')
            ->limit(5)
            ->latest()
            ->get();

        return $this->successResponse([
            'advertisements' => AdvertisementResource::collection($advertisements),
            'articles' => ArticleListResource::collection($articles),
            'open_consultations' => ConsultationResource::collection($open_consultations),
        ], __('messages.retrived', ['message' => __('main.data')]), 200);
    }
}
