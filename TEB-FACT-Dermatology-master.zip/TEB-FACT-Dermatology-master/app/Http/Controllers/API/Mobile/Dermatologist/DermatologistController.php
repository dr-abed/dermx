<?php

namespace App\Http\Controllers\API\Mobile\Dermatologist;

use App\Enums\DermatologistProfileStatus;
use App\Traits\HTTPResponses;
use App\Http\Controllers\Controller;
use App\Http\Requests\Mobile\StoreDermatologistRequest;
use App\Http\Requests\Mobile\UpdateDermatologistInformationRequest;
use App\Http\Requests\Mobile\UpdateDermatologistRequest;
use App\Http\Resources\DermatologistResource;
use App\Models\BaseModel;
use App\Models\Dermatologist;
use App\Traits\AuthProcessing;
use App\Traits\Loggable;
use App\Traits\ThrottlesLogins;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class DermatologistController extends Controller
{
    use HTTPResponses;
    use ThrottlesLogins, Loggable, AuthProcessing;

    private $guard = 'dermatologist';
    private $maxAttempts = 50000000000000;
    private $decayMinutes = 180;

    public function register(StoreDermatologistRequest $request)
    {
        $dermatologist = Dermatologist::create($request->validated());
        $dermatologist->update(['password' => bcrypt($request->password)]);
        return response()->json($this->getUser($dermatologist), 200);
    }

    public function completeProfile(UpdateDermatologistInformationRequest $request)
    {
        $dermatologist = $request->user('dermatologist');
        if ($dermatologist->profile_status->is(DermatologistProfileStatus::InComplete)) {
            $dermatologist->update(['profile_status' => DermatologistProfileStatus::NotApproved]);
        }
        $dermatologist->update($request->safe()->except(['university_certificate_image']));
        $dermatologist->generateMedia(['university_certificate_image' => $request->university_certificate_image]);
        $dermatologist->save();
        return $this->successResponse(null, __('messages.updated', ['message' => __('main.dermatologist')]), 200);
    }

    public function changePassword(Request $request)
    {
        $request->validate([
            'old_password' => 'required',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = $request->user('dermatologist');
        if (!Hash::check($request->old_password, $user->password)) {
            throw ValidationException::withMessages([
                'old_password'  => __('auth.password')
            ]);
        }

        $user->update(['password' => bcrypt($request->password)]);

        return response()->json(['message' => __('auth.password-reset')], 200);
    }

    public function logout(Request $request)
    {
        $request->user('dermatologist')->token()->revoke();
        return response()->json(['message' => __('auth.logged-out')], 200);
    }

    public function getUser($user)
    {
        return [
            'token' => $user->createToken('dermatologist', ['dermatologist'])->accessToken,
            'dermatologist' => DermatologistResource::make($user),
        ];
    }

    private function guard()
    {
        return Auth::guard('dermatologist');
    }

    public function update(UpdateDermatologistRequest $request)
    {
        $dermatologist = $request->user('dermatologist');
        $dermatologist->update($request->safe()->except(['profile_image']));
        $dermatologist->generateMedia(['profile_image' => $request->profile_image]);
        return $this->successResponse(['dermatologist' => DermatologistResource::make($dermatologist)], __('messages.updated', ['message' => __('main.dermatologist')]), 200);
    }

    public function profile(Request $request)
    {
        $dermatologist = $request->user('dermatologist');
        return $this->successResponse(['dermatologist' => DermatologistResource::make($dermatologist)], __('messages.retrived', ['message' => __('main.dermatologist')]), 200);
    }

    public function destroy(Request $request)
    {
        $request->user('dermatologist')->tokens()->update(['revoked' => true]);
        $request->user('dermatologist')->update(['fcm_token' => null]);
        $request->user('dermatologist')->delete();

        return $this->successResponse(null, __('messages.deleted', ['message' => __('main.dermatologist')]), 200);
    }

    public function sendEmailVerification(Request $request)
    {
        $dermatologist = $request->user('dermatologist');
        if ($dermatologist) {
            $verify_pin = DB::table('password_resets')->where('email', $dermatologist->email)->where('user_type', BaseModel::DERMATOLOGIST)->where('pin_type', 'email_verification');
            if ($verify_pin->exists()) {
                $verify_pin->delete();
            }
            $this->sendVerificationPINEmail($dermatologist);
        }
        return $this->successResponse(null, __('auth.pin-code-send'), 200);
    }

    public function verifyEmail(Request $request)
    {
        $request->validate([
            'pin' => 'required|numeric|digits:6',
        ]);
        $dermatologist = $request->user('dermatologist');
        if ($dermatologist) {
            $verify_pin = DB::table('password_resets')->where('email', $dermatologist->email)->where('user_type', BaseModel::DERMATOLOGIST)->where('pin_type', 'email_verification')->where('pin', $request->pin);
            if ($verify_pin->exists()) {
                $verify_pin->delete();
                $dermatologist->update(['email_verified_at' => now(), 'profile_status' => DermatologistProfileStatus::InComplete]);
                return response()->json($this->getUser($dermatologist), 200);
            }
        }
        return $this->errorResponse(null, __('auth.invalid-pin'), 422);
    }

    public function sendForgotPasswordEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:dermatologists,email',
        ]);
        $dermatologist = dermatologist::where('email', $request->email)->first();
        if ($dermatologist) {
            $verify_pin = DB::table('password_resets')->where('email', $dermatologist->email)->where('user_type', BaseModel::DERMATOLOGIST)->where('pin_type', 'forgot_password');
            if ($verify_pin->exists()) {
                $verify_pin->delete();
            }
            $this->sendForgotPasswordPINEmail($dermatologist);
        }
        return $this->successResponse(null, __('auth.pin-code-send'), 200);
    }

    public function verifyForgotPassword(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:dermatologists,email',
            'pin' => 'required|numeric|digits:6',
        ]);
        $dermatologist = dermatologist::where('email', $request->email)->first();
        if ($dermatologist) {
            $verify_pin = DB::table('password_resets')->where('email', $dermatologist->email)->where('user_type', BaseModel::DERMATOLOGIST)->where('pin_type', 'forgot_password')->where('pin', $request->pin);
            if ($verify_pin->exists()) {
                $verify_pin->delete();
                $token = $dermatologist->createToken('dermatologist', ['dermatologist'])->accessToken;
                return $this->successResponse($token, __('auth.pin-verified'), 200);
            }
        }
        return $this->errorResponse(null, __('auth.invalid-pin'), 422);
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'password' => 'required|string|min:8|confirmed',
        ]);
        $dermatologist = $request->user('dermatologist');
        if ($dermatologist) {
            $dermatologist->update(['password' => bcrypt($request->password)]);
            $dermatologist->tokens()->update(['revoked' => true]);
            return $this->successResponse(null, __('auth.password-reset'), 200);
        }
        return $this->errorResponse(null, __('auth.invalid-pin'), 422);
    }
}
