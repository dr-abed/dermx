<?php

namespace App\Http\Controllers\API\Mobile\Dermatologist;

use App\Http\Controllers\Controller;
use App\Http\Requests\Mobile\ArticleRequest;
use App\Http\Resources\Mobile\ArticleLangsResource;
use App\Http\Resources\Mobile\ArticleListResource;
use App\Http\Resources\Mobile\ArticleResource;
use App\Models\Article;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    use HTTPResponses;
    public function index(Request $request)
    {
        $articles = $request->user('dermatologist')
            ->articles()
            ->with('translations', 'media')
            ->latest()
            ->paginate($this->paginate($request));

        return $this->successResponse(ArticleListResource::collection($articles), __('messages.retrived', ['message' => __('main.articles')]), 200);
    }

    public function show(Request $request, Article $article)
    {
        $article = $request->user('dermatologist')
            ->articles()
            ->with('translations', 'media')
            ->findOrFail($article->id);

        return $this->successResponse(ArticleLangsResource::make($article), __('messages.retrived', ['message' => __('main.article')]), 200);
    }

    public function store(ArticleRequest $request)
    {
        $article = $request->user('dermatologist')
            ->articles()
            ->create($request->safe()->except('image'));

        $article->generateMedia(['image' => $request->image]);

        return $this->successResponse(null, __('messages.created', ['message' => __('main.article')]), 201);
    }

    public function update(ArticleRequest $request, Article $article)
    {
        $article = $request->user('dermatologist')
            ->articles()
            ->findOrFail($article->id);

        $article->update($request->safe()->except('image'));
        $article->generateMedia(['image' => $request->image]);

        return $this->successResponse(null, __('messages.updated', ['message' => __('main.article')]), 200);
    }

    public function destroy(Request $request, Article $article)
    {
        abort_if(!$request->user('dermatologist')->articles()->where('id', $article->id)->exists(), 403, __('messages.not_allowed'));
        $article->delete();
        return $this->successResponse(null, __('messages.deleted', ['message' => __('main.article')]), 200);
    }
}
