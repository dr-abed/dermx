<?php

namespace App\Http\Controllers\API\Mobile\Dermatologist;

use App\Enums\ConsultationStatus;
use App\Enums\NotificationClickAction;
use App\Http\Controllers\Controller;
use App\Http\Resources\Mobile\ConsultationResource;
use App\Models\Consultation;
use App\Models\Patient;
use App\Notifications\Mobile\ConsultationNotification;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;
use App\Http\Resources\Mobile\PatientHistoryResource;
use Illuminate\Notifications\Notification;

class ConsultationController extends Controller
{
    use HTTPResponses;
    public function index(Request $request)
    {
        $consultations = $request->user('dermatologist')
            ->consultations()->with('patient', 'consultationRate')
            ->when($request->status, fn ($query) => $query->where('status', $request->status))
            ->orderBy('updated_at', 'desc')
            ->paginate($this->paginate($request));
        return $this->successResponse(['consultations' => ConsultationResource::collection($consultations)], __('messages.retrived', ['message' => __('main.consultations')]), 200);
    }

    public function show(Consultation $consultation)
    {
        abort_if($consultation->dermatologist_id != request()->user('dermatologist')->id, 403, __('main.not_allowed'));
        $consultation->load('dermatologist', 'consultationRate');
        return $this->successResponse(['consultation' => ConsultationResource::make($consultation->load('dermatologist'))], __('messages.retrived', ['message' => __('main.consultation')]), 200);
    }


    public function generalConsultation(Request $request, Consultation $consultation)
    {
        $consultation->load('dermatologist', 'consultationRate', 'patient');
        //make the notification as read
        current_user()->notifications()->where('data->click_action', NotificationClickAction::Consultation)->where('data->target_id', $consultation->id)->update(['read_at' => now()]);
        return $this->successResponse(['consultation' => ConsultationResource::make($consultation->load(['dermatologist', 'patient']))], __('messages.retrived', ['message' => __('main.consultation')]), 200);
    }


    public function take(Request $request, Consultation $consultation)
    {
        $request->validate([
            'firebase_chat_room_id' => 'required|string',
        ]);
        abort_if($consultation->status != ConsultationStatus::New, 403, __('main.not_allowed'));
        abort_if($request->user('dermatologist')->remaining_consultations_count <= 0, 403, __('main.there_is_no_remaining_consultations'));
        $consultation->update([
            'status' => ConsultationStatus::Open,
            'dermatologist_id' => $request->user('dermatologist')->id,
            'firebase_chat_room_id' => $request->firebase_chat_room_id,
        ]);
        $consultation->save();
        //if the users don't fcmtoken don't send notification
        if ($consultation->patient->fcm_token) {
            $consultation->patient->notify(new ConsultationNotification($consultation));
        }
        if ($consultation->dermatologist->fcm_token) {
            $consultation->dermatologist->notify(new ConsultationNotification($consultation));
        }
        return $this->successResponse(null, __('messages.consultation_status_changed.' . ConsultationStatus::getKey($consultation->status)), 200);
    }

    public function close(Request $request, Consultation $consultation)
    {
        abort_if($consultation->status != ConsultationStatus::Open, 403, __('main.not_allowed'));
        abort_if($consultation->dermatologist_id != $request->user('dermatologist')->id, 403, __('main.not_allowed'));
        $consultation->update([
            'status' => ConsultationStatus::Closed,
        ]);
        $consultation->save();
        try {
            $consultation->dermatologist->notify(new ConsultationNotification($consultation));
            $consultation->patient->notify(new ConsultationNotification($consultation));
        } catch (\Throwable $th) {
            //throw $th;
        }
        return $this->successResponse(null, __('messages.consultation_status_changed.' . '.' . ConsultationStatus::getKey($consultation->status)), 200);
    }

    public function new_consultations(Request $request)
    {
        $consultations = Consultation::query()
            ->new()
            ->with('patient')
            ->latest()
            ->paginate($this->paginate($request));
        return $this->successResponse(['consultations' => ConsultationResource::collection($consultations)], __('messages.retrived', ['message' => __('main.consultations')]), 200);
    }

    public function patient_history(Patient $patient)
    {
        $patientHistories = $patient->patientHistories()->with('question')->get();
        return $this->successResponse(['history' => PatientHistoryResource::collection($patientHistories)], __('messages.retrived', ['message' => __('main.patient_history')]), 200);
    }
}
