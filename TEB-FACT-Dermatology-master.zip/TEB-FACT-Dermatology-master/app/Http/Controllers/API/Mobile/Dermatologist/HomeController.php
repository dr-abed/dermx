<?php

namespace App\Http\Controllers\API\Mobile\Dermatologist;

use App\Http\Controllers\Controller;
use App\Http\Resources\Mobile\AdvertisementResource;
use App\Http\Resources\Mobile\ConsultationResource;
use App\Models\Advertisement;
use App\Models\Article;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    use HTTPResponses;
    public function index(Request $request)
    {
        $advertisements = Advertisement::query()
            ->active()
            ->with('media')
            ->latest()
            ->get();

        $remaining_consultations_count = $request->user('dermatologist')
            ->remaining_consultations_count;

        $open_consultations = $request->user('dermatologist')
            ->consultations()
            ->open()
            ->with('patient')
            ->limit(5)
            ->latest()
            ->get();

        return $this->successResponse([
            'advertisements' => AdvertisementResource::collection($advertisements),
            'remaining_consultations_count' => $remaining_consultations_count,
            'open_consultations' => ConsultationResource::collection($open_consultations),
        ], __('messages.retrived', ['message' => __('main.data')]), 200);
    }
}
