<?php

namespace App\Http\Controllers\API\Mobile;

use App\Http\Controllers\Controller;
use App\Http\Resources\Mobile\PageResource;
use App\Http\Resources\Mobile\SiteSettingResource;
use App\Models\BaseModel;
use App\Models\Dermatologist;
use App\Models\Page;
use App\Models\Patient;
use App\Models\SiteSetting;
use App\Notifications\Mobile\ConsultationNotification;
use App\Notifications\Mobile\GlobalNotification;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    use HTTPResponses;
    public function index()
    {
        $pages = Page::query()->active()->with('translations', 'media')->get();
        $siteSetting = SiteSetting::first();
        return $this->successResponse([
            'pages' => PageResource::collection($pages),
            'site_setting' => SiteSettingResource::make($siteSetting),
        ], __('messages.retrived', ['message' => __('main.data')]), 200);
    }

    public function sendNotification(Request $request)
    {
        $request->validate([
            'message' => 'required|string',
            'sender_id' => 'required|int',
            'receiver_id' => 'required|int',
            'user_type' => 'required|string',
            'consultation_room_id' => 'required|string',
        ]);
        if ($request->user_type == BaseModel::PATIENT) {
            $receiver = Dermatologist::find($request->receiver_id);
        } else if ($request->user_type == BaseModel::DERMATOLOGIST) {
            $receiver = Patient::find($request->receiver_id);
        } else {
            return $this->errorResponse(null, __('main.invalid_user_type'), 422);
        }
        if ($receiver->fcm_token) {
            $receiver->notify(new GlobalNotification($request->message, $request->consultation_room_id));
        }
        return $this->successResponse(null, __('messages.sent', ['message' => __('main.notification')]), 200);
    }
}
