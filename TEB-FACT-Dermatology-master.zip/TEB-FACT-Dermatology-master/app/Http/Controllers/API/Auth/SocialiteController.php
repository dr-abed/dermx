<?php

namespace App\Http\Controllers\API\Auth;

use App\Enums\DermatologistProfileStatus;
use App\Traits\HTTPResponses;
use App\Traits\AuthProcessing;
use App\Http\Controllers\Controller;
use App\Http\Resources\DermatologistResource;
use App\Http\Resources\PatientResource;
use App\Models\BaseModel;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class SocialiteController extends Controller
{

    use HTTPResponses, AuthProcessing;

    public function handleProviderCallback(Request $request)
    {
        $validator = Validator::make($request->only('provider', 'access_provider_token', 'user_type', 'locale'), [
            'user_type' => ['required', 'string'],
            'provider' => ['required', 'string'],
            'access_provider_token' => ['required', 'string'],
            'locale' => ['required', 'string', 'in:en,ar']
        ]);
        if ($validator->fails())
            return response()->json($validator->errors(), 400);
        $user_type = $request->user_type;
        $locale = $request->locale;
        $provider = $request->provider;
        $validated = $this->validateProvider($provider);
        if (!is_null($validated))
            return $validated;
        $providerUser = Socialite::driver($provider)->userFromToken($request->access_provider_token);
        $user = $this->findOrCreateSocialiteUser($provider, $user_type, $providerUser, $locale);
        $data =  [
            'token' => $user->createToken($user_type, [$user_type])->accessToken,
            $user_type => $user_type == BaseModel::PATIENT ? PatientResource::make($user) : DermatologistResource::make($user),
        ];
        return response()->json($data, 200);
    }

    protected function validateProvider($provider)
    {
        if (!in_array($provider, ['google', 'facebook'])) {
            return response()->json(["message" => 'You can only login via google and facebook account'], 400);
        }
    }
}
