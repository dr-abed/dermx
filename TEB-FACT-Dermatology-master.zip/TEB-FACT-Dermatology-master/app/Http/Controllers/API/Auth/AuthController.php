<?php

namespace App\Http\Controllers\API\Auth;

use App\Enums\DermatologistProfileStatus;
use App\Models\Patient;
use App\Models\BaseModel;
use App\Models\Dermatologist;
use App\Traits\HTTPResponses;
use App\Models\PatientHistory;
use App\Traits\AuthProcessing;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\PatientHistoryQuestion;
use App\Http\Requests\Auth\LoginUserRequest;
use App\Http\Requests\Auth\StoreUserRequest;
use App\Models\Admin;

class AuthController extends Controller
{
    use HTTPResponses, AuthProcessing;

    public function login(LoginUserRequest $request)
    {
        $request->validated($request->all());
        $user = $this->whichUser($request);
        // if (!$user || !Hash::check($request->password, $user->password)) {
        //     return $this->errorResponse(null, 'The provided credentials are incorrect.', 401);
        // }
        // or:
        if (!Auth::guard($request->user_type)->attempt($request->only('email', 'password'))) {
            return $this->errorResponse(null, 'The password is incorrect.', 401);
        }
        if ($request->user_type == BaseModel::PATIENT) {
            $user->patient_history = $user->patientHistories()->get();
        }
        if ($this->checkEmailVerification($request, $user)) {
            return $this->errorResponse(["user" =>  $user, 'token' => $user->createToken('API Token of ' . $user->name)->plainTextToken], 'Please verify your email address.', 401);
        }
        $message = ucwords($request->user_type) . ' logged in successfully';
        if ($request->user_type == BaseModel::DERMATOLOGIST) {
            if ($user->profile_status == DermatologistProfileStatus::NotVerified) {
                $message = 'Please complete your profile';
            } else if ($user->profile_status == DermatologistProfileStatus::NotApproved) {
                $message = 'Your profile is pending for activation, Please wait for the admin to activate it';
            }
            return $this->errorResponse(['user' => $user, 'token' => $user->createToken('API Token of ' . $user->name)->plainTextToken], $message, 401);
        }
        unset($user->deleted_at);
        return $this->successResponse(['user' => $user, 'token' => $user->createToken('API Token of ' . $user->name)->plainTextToken], $message, 200);
    }

    public function register(StoreUserRequest $request)
    {
        $request->validated($request->all());
        $data = [
            'full_name' => $request->full_name,
            'email' => $request->email,
            'username' => $request->username,
            'mobile_number' => $request->mobile_number,
            'gender' => $request->gender,
            'date_of_birth' => $request->date_of_birth,
            'password' => Hash::make($request->password),
        ];
        if ($request->user_type == BaseModel::ADMIN) {
            $user = Admin::create($data);
        } else if ($request->user_type == BaseModel::DERMATOLOGIST) {
            $data['profile_status'] = Dermatologist::PROFILE_STATUS_NEW;
            $user = Dermatologist::create($data);
        } else {
            $user = Patient::create($data);
            // make history with no answers
            $questions = PatientHistoryQuestion::all();
            $questions->each(function ($question) use ($user) {
                PatientHistory::create([
                    'patient_id' => $user->id,
                    'question_id' => $question->id,
                ]);
            });
            // append the patient history to the user
            $user->patient_history = $user->patientHistories()->get();
        }
        if ($user) {
            $verify_pin = DB::table('password_resets')->where('email', $request->email)->where('user_type', $request->user_type)->where('pin_type', 'email_verification');
            if ($verify_pin->exists()) {
                $verify_pin->delete();
            }
            $this->sendVerificationPINEmail($request, $user);
        }
        $token = $user->createToken('API Token of ' . $user->name)->plainTextToken;
        // $user->sendEmailVerificationNotification(); // the normal way of sending email verification
        return $this->successResponse(['user' => $user, 'token' => $token], ucwords($request->user_type) . ' created successfully, Please check your email for a 6-digit pin to verify it.', 201);
    }
}
