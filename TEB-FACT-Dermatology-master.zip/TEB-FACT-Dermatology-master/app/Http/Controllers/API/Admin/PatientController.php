<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\UpdatePatientRequest;
use App\Http\Resources\PatientListResource;
use App\Http\Resources\PatientResource;
use App\Models\Patient;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    use HTTPResponses;

    //CRUD
    public function index(Request $request)
    {
        $patients = Patient::query()
            ->when($request->name, fn ($query, $name) => $query->where('full_name', 'LIKE', "%{$name}%"))
            ->latest()
            ->paginate($this->paginate($request));
        return PatientListResource::collection($patients);
    }

    public function show(Patient $patient)
    {
        return $this->successResponse(['patient' => PatientResource::make($patient)], __('messages.retrived', ['message' => __('main.patient')]), 200);
    }

    public function update(UpdatePatientRequest $request, Patient $patient)
    {
        $patient->update($request->safe()->except(['profile_image']));
        $patient->generateMedia(['profile_image' => $request->profile_image]);
        return $this->successResponse(['patient' => PatientResource::make($patient)], __('messages.updated', ['message' => __('main.patient')]), 200);
    }

    public function destroy(Patient $patient)
    {
        $patient->delete();
        return $this->successResponse(null, __('messages.deleted', ['message' => __('main.patient')]), 200);
    }
}
