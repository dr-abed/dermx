<?php

namespace App\Http\Controllers\API\Admin;

use App\Enums\DermatologistProfileStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\UpdateDermatologistRequest;
use App\Http\Resources\DermatologistListResource;
use App\Http\Resources\DermatologistResource;
use App\Models\Dermatologist;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class DermatologistController extends Controller
{
    use HTTPResponses;

    //CRUD
    public function index(Request $request)
    {
        $dermatologists = Dermatologist::query()
            ->active()
            ->when($request->name, fn ($query, $name) => $query->where('full_name', 'LIKE', "%{$name}%"))
            ->latest()
            ->paginate($this->paginate($request));
        return DermatologistListResource::collection($dermatologists);
    }

    public function show(Dermatologist $dermatologist)
    {
        return $this->successResponse(DermatologistResource::make($dermatologist), __('messages.retrived', ['message' => __('main.dermatologist')]), 200);
    }

    public function update(UpdateDermatologistRequest $request, Dermatologist $dermatologist)
    {
        $dermatologist->update($request->safe()->except(['profile_image','university_certificate_image']));
        $dermatologist->generateMedia(['profile_image' => $request->profile_image , 'university_certificate_image' => $request->university_certificate_image]);
        return $this->successResponse(['dermatologist' => DermatologistResource::make($dermatologist)], __('messages.updated', ['message' => __('main.dermatologist')]), 200);
    }

    // public function activate(Dermatologist $dermatologist)
    // {
    //     if ($dermatologist->profile_status->is(DermatologistProfileStatus::Approved)) {
    //         $dermatologist->update(['profile_status' => DermatologistProfileStatus::NotApproved]);
    //         return $this->successResponse(null, __('messages.deactivated', ['message' => __('main.dermatologist')]), 200);
    //     } else {
    //         $dermatologist->update(['profile_status' => DermatologistProfileStatus::Approved]);
    //         return $this->successResponse(null, __('messages.activated', ['message' => __('main.dermatologist')]), 200);
    //     }
    // }

    public function destroy(Dermatologist $dermatologist)
    {
        $dermatologist->delete();
        return $this->successResponse(null, __('messages.deleted', ['message' => __('main.dermatologist')]), 200);
    }
}
