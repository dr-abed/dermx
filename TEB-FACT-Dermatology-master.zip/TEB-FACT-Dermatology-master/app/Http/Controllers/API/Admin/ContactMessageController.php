<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ContactMessageRequest;
use App\Http\Resources\ContactMessageResource;
use App\Mail\ContactMessageMail;
use App\Mail\ReplyContactMessageMail;
use App\Models\ContactMessage;
use App\Models\EmailTemplate;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactMessageController extends Controller
{
    use HTTPResponses;

    public function index(Request $request)
    {
        $contactMessages = ContactMessage::query()->orderBy('created_at', 'desc')->paginate($this->paginate($request));
        return ContactMessageResource::collection($contactMessages);
    }

    public function store(ContactMessageRequest $request)
    {
        $template = EmailTemplate::where('type', 'contact_message')->firstOrFail();
        ContactMessage::create($request->validated());
        $body = $template->getBody();
        Mail::to($request->email)->send(new ContactMessageMail($template, $body));

        return $this->successResponse(null, __('messages.created', ['message' => __('main.contactMessage')]), 201);
    }

    public function show(ContactMessage $contactMessage)
    {
        $contactMessage->update(['is_read' => true]);
        return $this->successResponse(ContactMessageResource::make($contactMessage), __('messages.retrived', ['message' => __('main.contactMessage')]), 200);
    }

    public function reply(Request $request, ContactMessage $contactMessage)
    {
        $request->validate(['message' => 'required|string']);
        $template = EmailTemplate::where('type', 'reply_contact_message')->firstOrFail();
        $body = $template->getBody($request->message);
        Mail::to($contactMessage->email)->send(new ReplyContactMessageMail($template, $body));
        $contactMessage->update(['is_read' => true]);
        $contactMessage->delete();
        return $this->successResponse(null, __('messages.created', ['message' => __('main.contactMessage')]), 200);
    }
}
