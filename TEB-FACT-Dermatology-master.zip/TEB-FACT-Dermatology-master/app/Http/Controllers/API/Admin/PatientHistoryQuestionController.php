<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\PatientHistoryQuestionRequest;
use App\Http\Resources\PatientHistoryQuestionResource;
use App\Models\Patient;
use App\Models\PatientHistoryQuestion;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class PatientHistoryQuestionController extends Controller
{
    use HTTPResponses;

    public function index(Request $request)
    {
        $questions = PatientHistoryQuestion::query()
            ->latest()
            ->paginate($this->paginate($request));
        return PatientHistoryQuestionResource::collection($questions);
    }

    public function store(PatientHistoryQuestionRequest $request)
    {
        $request->validated();
        $question = new  PatientHistoryQuestion();
        $question->fill([
            'type' => $request->type,
            'ar' => [
                'question' => $request->ar['question'],
                'options' => json_encode($request->ar['options'] ?? []),
            ],
            'en' => [
                'question' => $request->en['question'],
                'options' => json_encode($request->en['options'] ?? []),
            ],
        ]);
        $question->save();

        //add this question to all patients
        $patients = Patient::all();
        foreach ($patients as $patient) {
            $patient->patientHistories()->create([
                'question_id' => $question->id,
                'answer' => null,
            ]);
        }
        return $this->successResponse(['question' => new PatientHistoryQuestionResource($question)], __('messages.created', ['message' => __('main.question')]), 201);
    }

    public function update(PatientHistoryQuestionRequest $request, PatientHistoryQuestion $question)
    {
        $request->validated();
        $question->fill([
            'type' => $request->type,
            'ar' => [
                'question' => $request->ar['question'],
                // 'options' => json_encode($request->ar['options']),
            ],
            'en' => [
                'question' => $request->en['question'],
                // 'options' => json_encode($request->en['options']),
            ],
        ]);
        $question->save();
        return $this->successResponse(['question' => new PatientHistoryQuestionResource($question)], __('messages.updated', ['message' => __('main.question')]), 200);
    }

    public function destroy(PatientHistoryQuestion $question)
    {
        $question->delete();
        //delete this question from all patients
        $patients = Patient::all();
        foreach ($patients as $patient) {
            $patient->patientHistories()->where('question_id', $question->id)->delete();
        }
        return $this->successResponse(null, __('messages.deleted', ['message' => __('main.question')]), 200);
    }
}
