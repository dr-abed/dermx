<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\ConsultationResource;
use App\Models\Consultation;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class ConsultationController extends Controller
{
    use HTTPResponses;

    public function index(Request $request)
    {
        $consultations = Consultation::query()
            ->with('dermatologist', 'patient')
            ->latest()
            ->paginate($this->paginate($request));
        return ConsultationResource::collection($consultations);
    }
}
