<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\ConsultationResource;
use App\Models\Consultation;
use App\Models\Dermatologist;
use App\Models\Patient;
use App\Traits\HTTPResponses;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Termwind\Components\Dd;

class HomeController extends Controller
{
    use HTTPResponses;
    public function index(Request $request)
    {
        $start_date = Carbon::parse($request->start_date)->startOfDay();
        $end_date = Carbon::parse($request->end_date)->endOfDay();

        $dermatologists = Dermatologist::query()
            ->active()
            ->whereBetween('created_at', [$start_date, $end_date])
            ->latest()
            ->count();
        $consultations = Consultation::query()
            ->whereBetween('created_at', [$start_date, $end_date])
            ->latest()
            ->count();
        $patients = Patient::query()
            ->whereBetween('created_at', [$start_date, $end_date])
            ->latest()
            ->count();

        //Chart js
        // for loop to get all dates between start and end date
        $labels = [];
        $start = clone $start_date;
        $end = clone $end_date;
        for ($date = $start; $date->lte($end); $date->addDay()) {
            $labels[] = $date->format('Y-m-d');
        }

        $consultations_chart = Consultation::query()
            ->whereBetween('created_at', [$start_date, $end_date])
            ->select(DB::raw('DATE(created_at) as date'), DB::raw('count(*) as count'))
            ->groupBy('date')
            ->get()
            ->pluck('count', 'date')
            ->toArray();

        $consultations_chart_keys = array_keys($consultations_chart);
        foreach ($labels as $label) {
            if (!in_array($label, $consultations_chart_keys)) {
                $consultations_chart[$label] = 0;
            }
        }

        $consultations_chart =  array_values($consultations_chart);

        $patients_chart = Patient::query()
            ->whereBetween('created_at', [$start_date, $end_date])
            ->select(DB::raw('DATE(created_at) as date'), DB::raw('count(*) as count'))
            ->groupBy('date')
            ->get()
            ->pluck('count', 'date')
            ->toArray();

        $patients_chart_keys = array_keys($patients_chart);
        foreach ($labels as $label) {
            if (!in_array($label, $patients_chart_keys)) {
                $patients_chart[$label] = 0;
            }
        }

        $patients_chart =  array_values($patients_chart);

        return $this->successResponse(['data' => [
            'dermatologists' => $dermatologists,
            'consultations' => $consultations,
            'patients' => $patients,
            'chart' => [
                'labels' => $labels,
                'consultations' => $consultations_chart,
                'patients' => $patients_chart,
            ]
        ]], __('messages.retrived', ['message' => __('main.data')]), 200);
    }

    public function last_consultations(Request $request)
    {
        $last_consultations = Consultation::query()->with('dermatologist', 'patient')->orderBy('created_at', 'desc')->paginate($this->paginate($request));
        return ConsultationResource::collection($last_consultations);
    }
}
