<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\AdvertisementRequest;
use App\Http\Resources\AdvertisementResource;
use App\Models\Advertisement;
use App\Models\AdvertisementImage;
use App\Rules\Base64Rule;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class AdvertisementController extends Controller
{
    use HTTPResponses;

    public function index(Request $request)
    {
        $advertisments = Advertisement::query()
            ->with('media')
            ->latest()
            ->paginate($this->paginate($request));
        return AdvertisementResource::collection($advertisments);
    }

    public function show(Advertisement $advertisement)
    {
        return $this->successResponse(AdvertisementResource::make($advertisement), __('messages.retrived', ['message' => __('main.advertisement')]), 200);
    }

    public function store(AdvertisementRequest $request)
    {
        $advertisement = Advertisement::create($request->safe()->except('image'));
        $advertisement->generateMedia(['image' => $request->image]);
        return $this->successResponse(null, __('messages.created', ['message' => __('main.advertisement')]), 201);
    }

    public function update(Request $request, Advertisement $advertisement)
    {
        $request->validate([
            'status' => ['required', 'boolean'],
            'link' => ['nullable', 'url'],
            'image' => ['nullable', new Base64Rule(8192)],
        ]);
        $advertisement->update($request->except('image'));
        if ($request->has('image')) {
            $advertisement->generateMedia(['image' => $request->image]);
        }
        return $this->successResponse(null, __('messages.updated', ['message' => __('main.advertisement')]), 200);
    }

    public function destroy(Advertisement $advertisement)
    {
        $advertisement->delete();
        return $this->successResponse(null, __('messages.deleted', ['message' => __('main.advertisement')]), 200);
    }
}
