<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\UpdateAdminRequest;
use App\Http\Resources\AdminResource;
use App\Models\Admin;
use App\Traits\HTTPResponses;
use App\Traits\Loggable;
use App\Traits\ThrottlesLogins;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AdminController extends Controller
{
    use HTTPResponses, ThrottlesLogins, Loggable;

    private $guard = 'admin';
    private $maxAttempts = 50000000000000;
    private $decayMinutes = 180;

    public function changePassword(Request $request)
    {
        $request->validate([
            'old_password' => 'required',
            'password' => 'required|string|min:8',
        ]);

        $user = $request->user('admin');
        if (!Hash::check($request->old_password, $user->password)) {
            throw ValidationException::withMessages([
                'old_password'  => __('auth.password')
            ]);
        }

        $user->update(['password' => bcrypt($request->password)]);
        $user->tokens()->delete();
        return response()->json(['message' => __('auth.password-reset')], 200);
    }

    public function logout(Request $request)
    {
        $request->user('admin')->token()->revoke();
        return response()->json(['message' => __('auth.logged-out')], 200);
    }

    public function getUser($user)
    {
        return [
            'token' => $user->createToken('admin', ['admin'])->accessToken,
            'admin' => AdminResource::make($user),
        ];
    }

    private function guard()
    {
        return Auth::guard('admin');
    }

    public function update(UpdateAdminRequest $request, Admin $admin)
    {
        $admin->update($request->safe()->except(['profile_image']));
        $admin->generateMedia(['profile_image' => $request->image]);
        return $this->successResponse(['admin' => AdminResource::make($admin)], __('messages.updated', ['message' => __('main.admin')]), 200);
    }

    public function checkToken(Request $request)
    {
        if ($request->user('admin')) {
            return $this->successResponse(null, __('messages.valid'), 200);
        } else {
            return $this->errorResponse(null, __('messages.invalid'), 401);
        }
    }
}
