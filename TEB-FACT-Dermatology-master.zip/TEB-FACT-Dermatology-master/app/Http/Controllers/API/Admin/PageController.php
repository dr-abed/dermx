<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\PageRequest;
use App\Http\Resources\PageResource;
use App\Models\Page;
use App\Models\SiteSetting;
use App\Traits\HTTPResponses;
use Illuminate\Http\Request;

class PageController extends Controller
{
    use HTTPResponses;

    public function index(Request $request)
    {
        $pages = Page::query()
            ->with('translations', 'media')
            ->latest()
            ->paginate($this->paginate($request));
        return  PageResource::collection($pages);
    }

    public function show(Page $page)
    {
        $page->load('media');
        return $this->successResponse(PageResource::make($page), __('messages.retrived', ['message' => __('main.page')]), 200);
    }

    public function store(PageRequest $request)
    {

        $attributes = array_merge(
            $request->safe()->except('slug', 'icon'),
            array_merge(
                $request->safe()->except('slug', 'icon'),
                ['slug' => str()->slug($request->input('en.title'))]
            )
        );
        Page::create($attributes)->generateMedia(['icon' => $request->icon]);
        return $this->successResponse(null, __('messages.created', ['message' => __('main.page')]), 201);
    }


    public function update(PageRequest $request, Page $page)
    {
        $attributes = array_merge(
            $request->safe()->except('slug', 'icon'),
            array_merge(
                $request->safe()->except('slug', 'icon'),
                ['slug' => str()->slug($request->input('en.title'))]
            )
        );
        tap($page, fn ($v) => $v->update($attributes));
        if ($request->has('icon')) {
            $page->generateMedia(['icon' => $request->icon]);
        }
        return $this->successResponse(null, __('messages.updated', ['message' => __('main.page')]), 200);
    }

    public function updateStatus(Request $request, Page $page)
    {
        $page->update(['status' => $request->boolean('status')]);
        return $this->successResponse(null, __('messages.updated', ['message' => __('main.page')]), 200);
    }

    public function destroy(Page $page)
    {
        $page->delete();
        return $this->successResponse(null, __('messages.deleted', ['message' => __('main.page')]), 200);
    }

    public function updateSiteSetting(Request $request)
    {
        $request->validate([
            'email' => 'required|email|max:255',
            'mobile_number' => 'required|string|max:255',
            'facebook' => 'required|string|max:255|url',
            'twitter' => 'nullable|string|max:255|url',
            'instagram' => 'required|string|max:255|url',
            'website' => 'required|string|max:255|url',
            'whatsapp' => 'required|string|max:255|url',
        ]);
        $site_setting = SiteSetting::first();
        $site_setting->update($request->all());
        return $this->successResponse(null, __('messages.updated', ['message' => __('main.site_setting')]), 200);
    }
}
