<?php

namespace App\Http\Resources;

use App\Enums\DermatologistProfileStatus;
use Illuminate\Http\Resources\Json\JsonResource;

class DermatologistResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'profile_image' => $this->profile_image,
            'full_name' => $this->full_name,
            'email' => $this->email,
            'mobile_number' => $this->mobile_number,
            'gender' => $this->gender,
            'date_of_birth' => $this->date_of_birth,
            'profile_status' => $this->profile_status ?? DermatologistProfileStatus::NotVerified,
            'maximum_no_of_open_consultations' => $this->maximum_no_of_open_consultations,
            'consultations_count' => $this->consultations_count,
            'rating' => $this->rating,
            'university_certificate_image' => $this->university_certificate_image,
            'university_certificate_file_name' => $this->university_certificate_file_name,
            'medical_specialty' => $this->medical_specialty,
            'experience_years' => $this->experience_years,
            'graduation_year' => $this->graduation_year,
            'locale' => $this->locale,
            'fc_token' => $this->fc_token,
            'email_verified_at' => $this->email_verified_at,
            'created_at' => $this->created_at,
        ];
    }
}
