<?php

namespace App\Http\Resources;

use App\Enums\ConsultationStatus;
use App\Models\Consultation;
use Illuminate\Http\Resources\Json\JsonResource;

class ConsultationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'dermatologist' => $this->dermatologist != null ? DermatologistResource::make($this->whenLoaded('dermatologist'))->only(['id', 'full_name', 'email', 'profile_image']) : null,
            'patient' => $this->patient != null ? PatientResource::make($this->whenLoaded('patient'))->only(['id', 'full_name', 'email', 'profile_image']) : null,
            'status' => $this->status ?? ConsultationStatus::New,
            'notes' => $this->notes,
            'firebase_chat_room_id' => $this->firebase_chat_room_id,
            'consultation_rate' => new ConsultationRateResource($this->whenLoaded('consultationRate')),
            'created_at' => $this->created_at,
        ];
    }
}
