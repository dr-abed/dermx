<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PatientHistoryQuestionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $translations = $this->getTranslationsArray();
        $array = [
            'id' => $this->id,
            'type' => $this->type->value,
        ];
        return array_merge($array, $translations);
    }
}
