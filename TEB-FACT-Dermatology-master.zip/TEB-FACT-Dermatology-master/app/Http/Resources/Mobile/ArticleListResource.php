<?php

namespace App\Http\Resources\Mobile;

use App\Http\Resources\DermatologistListResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ArticleListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'image' => $this->image,
            'title' => $this->title,
            'description' => mb_substr($this->description, 0, 100),
            'dermatologist' => $this->dermatologist->full_name,
            'number_of_views' => $this->number_of_views,
            'created_at' => $this->created_at,
        ];
    }
}
