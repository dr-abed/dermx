<?php

namespace App\Http\Resources\Mobile;

use App\Http\Resources\DermatologistListResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ArticleLangsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $arabic  = $this->translations->where('locale', 'ar')->first();
        $english = $this->translations->where('locale', 'en')->first();
        return [
            'id' => $this->id,
            'image' => $this->image,
            'title_en' => $english->title,
            'title_ar' => $arabic->title,
            'description_en' => $english->description,
            'description_ar' => $arabic->description,
            'dermatologist' => new DermatologistListResource($this->whenLoaded('dermatologist')),
            'number_of_views' => $this->number_of_views,
            'created_at' => $this->created_at,
        ];
    }
}
