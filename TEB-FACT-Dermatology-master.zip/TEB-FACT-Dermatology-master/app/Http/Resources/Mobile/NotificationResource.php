<?php

namespace App\Http\Resources\Mobile;

use App\Notifications\Mobile\ConsultationNotification;
use Illuminate\Http\Resources\Json\JsonResource;

class NotificationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $data = $this->data;
        $type = match ($this->type) {
            ConsultationNotification::class => [
                'title' => __($this->data['title'], ['dermatologist' => $dermatologist ?? null]),
                'body' => __($this->data['body']),
                'payload' => null,
            ],
            default => [
                'title' => $this->data['title'],
                'body' => $this->data['body'],
                'payload' => $this->data['payload'] ?? null,
            ],
        };

        return [
            'id'                => $this->id,
            'title'             => $type['title'] ?? null,
            'body'              => $type['body'] ?? null,
            'target_id'         => $data['target_id'] ?? null,
            'click_action'      => $data['click_action'] ?? null,
            "payload"           => $type['payload'] ?? null,
            'image'             => $data['image'] ?? null,
            'read_at'           => $this->read_at?->format('Y-m-d H:i:s') ?? null,
            'created_at'        => $this->created_at->format('Y-m-d H:i:s') ?? null,
        ];
    }
}
