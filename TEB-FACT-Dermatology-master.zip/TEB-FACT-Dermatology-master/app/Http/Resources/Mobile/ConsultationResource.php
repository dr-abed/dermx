<?php

namespace App\Http\Resources\Mobile;

use App\Enums\ConsultationStatus;
use App\Http\Resources\PatientResource;
use App\Http\Resources\PatientListResource;
use App\Http\Resources\DermatologistResource;
use App\Http\Resources\ConsultationRateResource;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\DermatologistListResource;

class ConsultationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'dermatologist' => $this->whenLoaded('dermatologist') != null ? DermatologistListResource::make($this->whenLoaded('dermatologist')) : null,
            'patient' => $this->whenLoaded('patient') != null ? PatientListResource::make($this->whenLoaded('patient')) : null,
            'status' => $this->status,
            'notes' => encryptData($this->notes),
            'images' => $this->all_images,
            'consultation_rate' => new ConsultationRateResource($this->whenLoaded('consultationRate')),
            'firebase_chat_room_id' => $this->firebase_chat_room_id,
            'created_at' => $this->created_at,
        ];
    }
}
