<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class DermatologistListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'profile_image' => $this->profile_image,
            'full_name' => $this->full_name,
            'email' => $this->email,
            'mobile_number' => $this->mobile_number,
            'profile_status' => $this->profile_status,
            'maximum_no_of_open_consultations' => $this->maximum_no_of_open_consultations,
            'consultations_count' => $this->consultations_count,
            'medical_specialty' => $this->medical_specialty,
            'rating' => $this->rating,
            'reviews' => $this->rating_count,
            'created_at' => $this->created_at,
        ];
    }
}
