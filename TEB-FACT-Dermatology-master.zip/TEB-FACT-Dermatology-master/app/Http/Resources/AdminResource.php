<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AdminResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->full_name,
            'image'=> $this->profile_image,
            'email' => $this->email,
            'mobile_number' => $this->mobile_number,
            'gender' => $this->gender?->description,
            'date_of_birth' => $this->date_of_birth,
            'locale' => $this->locale,
        ];
    }
}
