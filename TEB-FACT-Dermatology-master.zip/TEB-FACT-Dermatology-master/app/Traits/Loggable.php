<?php

namespace App\Traits;

use App\Enums\DermatologistProfileStatus;
use App\Models\Admin;
use App\Models\Dermatologist;
use App\Models\Patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Validation\ValidationException;


trait Loggable
{
    public function login(Request $request)
    {
        $this->validateLogin($request);

        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if (
            method_exists($this, 'hasTooManyLoginAttempts') &&
            $this->hasTooManyLoginAttempts($request)
        ) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }

        if ($this->attemptLogin($request)) {
            if ($request->hasSession()) {
                $request->session()->put('auth.password_confirmed_at', time());
            }

            return $this->sendLoginResponse($request);
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        $this->incrementLoginAttempts($request);

        return $this->sendFailedLoginResponse($request);
    }

    protected function validateLogin(Request $request)
    {
        $request->validate(
            [
                $this->username() => 'required|string',
                'password' => 'required|string',
            ]
        );
    }

    protected function attemptLogin(Request $request)
    {
        if ($request->is('api/admin/*')) {
            $user = Admin::findByEmail($request->email);
            if (!$user || !Hash::check($request->password, $user->password)) {
                throw ValidationException::withMessages([
                    'email' => [__('auth.failed')],
                ]);
            }
            return true;
        } else if ($request->is('api/patient/*')) {
            $user = Patient::findByEmail($request->email);
            if (!$user || !Hash::check($request->password, $user->password)) {
                throw ValidationException::withMessages([
                    'email' => [__('auth.failed')],
                ]);
            }
            return true;
        } else if ($request->is('api/dermatologist/*')) {
            $user = Dermatologist::findByEmail($request->email);
            if (!$user || !Hash::check($request->password, $user->password)) {
                throw ValidationException::withMessages([
                    'email' => [__('auth.failed')],
                ]);
            }
            return true;
        }

        return $this->guard()->attempt(
            $this->credentials($request),
            $request->filled('remember')
        );
    }

    protected function credentials(Request $request)
    {
        return $request->only($this->username(), 'password');
    }

    protected function sendLoginResponse(Request $request)
    {
        $this->clearLoginAttempts($request);

        if ($request->is('api/admin/*')) {
            return response()->json($this->getUser(Admin::findByEmail($request->email)), 200);
        } else if ($request->is('api/patient/*')) {
            return response()->json($this->getUser(Patient::findByEmail($request->email)), 200);
        } else if ($request->is('api/dermatologist/*')) {
            $dermatologist = Dermatologist::findByEmail($request->email);
            return response()->json($this->getUser($dermatologist), 200);
        }

        $request->session()->regenerate();

        return get_segment(Session::get('url.intended')) == 'admin' ? redirect()->intended($this->redirectTo) : redirect($this->redirectTo);
    }

    protected function sendFailedLoginResponse(Request $request)
    {
        throw ValidationException::withMessages([
            $this->username() => [__('auth.failed')],
        ]);
    }

    public function logout(Request $request)
    {
        $this->guard()->logout();
        return $this->loggedOut($request) ?: redirect('/');
    }

    public function loggedOut(Request $request)
    {
        return redirect($this->redirectTo);
    }

    public function username()
    {
        return 'email';
    }

    private function guard()
    {
        return  Auth::guard('admin');
    }
}
