<?php

namespace App\Traits;

trait HTTPResponses
{
    // Status codes: 200, 201, 202, 204, 400, 401, 403, 404, 405, 422, 500
    // 200 : OK, Success, 201 : Created, Success, 202 : Accepted, Success, 204 : No Content, Success, 400 : Bad Request, Error
    // 401 : Unauthorized, Error, 404 : Not Found, Error, 405 : Method Not Allowed, Error, 422 : Unprocessable Entity, Error,
    // 500 : Internal Server Error, Error

    /**
     * @param string $message
     * @param int $code
     * @return \Illuminate\Http\JsonResponse
     */
    protected function successResponse($data, string $message = null, int $code = 200)
    {
        $jsonResponse = [
            'status' => true,
            'message' => $message,
        ];
        if ($data) {
            $jsonResponse['data'] = $data;
        }
        return response()->json($jsonResponse, $code);
    }

    /**
     * @param string $message
     * @param int $code
     * @return \Illuminate\Http\JsonResponse
     */
    protected function errorResponse($data, string $message = null, $code)
    {
        $jsonResponse = [
            'status' => false,
            'message' => $message,
        ];
        if ($data) {
            $jsonResponse['data'] = $data;
        }
        return response()->json($jsonResponse, $code);
    }
}
