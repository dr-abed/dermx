<?php

namespace App\Traits;

trait HasEmail
{
  public function scopeEmail($q, $v)
  {
    return $q->where('email', $v);
  }

  public static function findByEmail($v)
  {
    return self::email($v)->first();
  }
}
