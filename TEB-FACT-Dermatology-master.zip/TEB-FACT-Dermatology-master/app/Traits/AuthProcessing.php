<?php

namespace App\Traits;

use App\Enums\DermatologistProfileStatus;
use Carbon\Carbon;
use App\Models\BaseModel;
use App\Mail\VerifyEmailMail;
use App\Models\Dermatologist;
use App\Mail\ResetPasswordMail;
use App\Models\Admin;
use App\Models\Patient;
use App\Models\PatientHistory;
use App\Models\PatientHistoryQuestion;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

trait AuthProcessing
{
    public function sendVerificationPINEmail($user)
    {
        $pin = rand(100000, 999999);
        $user_type = $user instanceof Admin ? BaseModel::ADMIN : ($user instanceof Dermatologist ? BaseModel::DERMATOLOGIST : BaseModel::PATIENT);
        DB::table('password_resets')
            ->insert([
                'email' => $user->email,
                'user_type' => $user_type,
                'pin' => $pin,
                'pin_type' => 'email_verification',
                'created_at' => Carbon::now(),
            ]);
        Mail::to($user->email)->send(new VerifyEmailMail($pin, $user, $user_type));
    }

    public function sendForgotPasswordPINEmail($user)
    {
        $pin = rand(100000, 999999);
        $user_type = $user instanceof Admin ? BaseModel::ADMIN : ($user instanceof Dermatologist ? BaseModel::DERMATOLOGIST : BaseModel::PATIENT);
        DB::table('password_resets')
            ->insert([
                'email' => $user->email,
                'user_type' => $user_type,
                'pin' => $pin,
                'pin_type' => 'forgot_password',
                'created_at' => Carbon::now(),
            ]);
        Mail::to($user->email)->send(new ResetPasswordMail($pin, $user, $user_type));
    }

    public function findOrCreateSocialiteUser($provider, $user_type, $providerUser, $locale)
    {
        $provider_id = $provider . '_id';
        $user = $user_type == BaseModel::DERMATOLOGIST ? DERMATOLOGIST::where('email', $providerUser->getEmail())->orWhere($provider_id, $providerUser->getId()) : Patient::where('email', $providerUser->getEmail())->orWhere($provider_id, $providerUser->getId());
        if ($user->exists()) {
            return $user->first();
        } else {
            // Auto Generate Password
            $password = Hash::make(Str::random(8));
            $data = [
                'full_name' => $providerUser->getName(),
                'email' => $providerUser->getEmail(),
                'password' => $password,
                'email_verified_at' => Carbon::now(),
                'locale' => $locale,
                $provider_id => $providerUser->getId(),
            ];
            $user = $user_type == BaseModel::DERMATOLOGIST ? Dermatologist::Create($data) : Patient::Create($data);
            if ($user_type == BaseModel::PATIENT) {
                // make history with no answers
                $questions = PatientHistoryQuestion::all();
                $questions->each(function ($question) use ($user) {
                    PatientHistory::create([
                        'patient_id' => $user->id,
                        'question_id' => $question->id,
                    ]);
                });
            } else if ($user_type == BaseModel::DERMATOLOGIST) {
                $user->update(['profile_status' => DermatologistProfileStatus::InComplete]);
            }
            $user->markEmailAsVerified();
            return $user_type == BaseModel::DERMATOLOGIST ? Dermatologist::find($user->id) : Patient::find($user->id);
        }
    }
}
