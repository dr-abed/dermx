<?php

namespace App\Traits;

use App\Models\Admin;
use Illuminate\Support\Facades\Route;

trait Booted
{
  public static function booted() {
    static::creating(function ($model) {
      $model->created_by = optional(auth_admin())->id;
    });
    static::updating(function ($model) {
      $model->updated_by = optional(auth_admin())->id;
    });
  }

  public function created_by_admin()
  {
    return $this->belongsTo(Admin::class, 'created_by');
  }

}
