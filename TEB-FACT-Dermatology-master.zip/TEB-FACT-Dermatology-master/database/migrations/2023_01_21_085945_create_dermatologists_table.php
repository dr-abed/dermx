<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDermatologistsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dermatologists', function (Blueprint $table) {
            $table->id();
            $table->string('full_name');
            $table->string('email', 160);
            $table->string('gender')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('mobile_number')->nullable();
            $table->date('date_of_birth')->nullable();
            $table->string('password');
            $table->char('locale', 2)->default('ar');
            $table->unsignedInteger('profile_status')->default(0);
            $table->unsignedInteger('maximum_no_of_open_consultations')->default(5);
            $table->string('fcm_token')->nullable();
            $table->text('google_id')->nullable();
            $table->text('facebook_id')->nullable();
            $table->string('apple_id')->nullable();
            //Information
            $table->string('medical_specialty')->nullable();
            $table->float('experience_years')->nullable();
            $table->unsignedInteger('graduation_year')->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dermatologists');
    }
}
