<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePatientHistoryQuestionTranslationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patient_history_question_translations', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('phq_id');
            $table->foreign('phq_id')->references('id')->on('patient_history_questions')->onDelete('cascade');
            $table->char('locale', 2)->index();
            $table->unique(['phq_id', 'locale']);
            $table->string('question');
            $table->text('options')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patient_history_question_translations');
    }
};
