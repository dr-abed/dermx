<?php

namespace Database\Factories;

use App\Models\Dermatologist;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Dermatologist>
 */
class DermatologistFactory extends Factory
{
    protected $model = Dermatologist::class;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'full_name' => $this->faker->name,
            'email' => $this->faker->email,
            'password' => bcrypt(12345678),
            'mobile_number' => $this->faker->phoneNumber,
            'graduation_year' => $this->faker->year,
            'experience_years' => $this->faker->randomFloat(2, 2, 4),
            'medical_specialty' => $this->faker->word,
        ];
    }
}
