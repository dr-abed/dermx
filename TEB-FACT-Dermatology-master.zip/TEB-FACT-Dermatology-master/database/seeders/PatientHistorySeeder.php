<?php

namespace Database\Seeders;

use App\Models\Article;
use Illuminate\Database\Seeder;

class PatientHistorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $patients =  \App\Models\Patient::factory(10)->create();
        \App\Models\Dermatologist::factory(6)->create();
        $this->call([ArticleSeeder::class]);
        // $consultations = \App\Models\Consultation::factory(10)->create();
        // $questions = \App\Models\PatientHistoryQuestion::all();
        // $patients->each(function ($patient) use ($questions) {
        //     $questions->each(function ($question) use ($patient) {
        //         \App\Models\PatientHistory::factory()->create([
        //             'patient_id' => $patient->id,
        //             'question_id' => $question->id,
        //             'answer' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        //         ]);
        //     });
        // });
    }
}
