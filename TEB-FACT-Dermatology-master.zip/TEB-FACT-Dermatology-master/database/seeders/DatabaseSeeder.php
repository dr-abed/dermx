<?php

namespace Database\Seeders;

use App\Models\Admin;
use App\Models\ContactMessage;
use App\Models\Patient;
use App\Models\SiteSetting;
use Illuminate\Database\Seeder;
use Database\Seeders\PatientHistorySeeder;
use Database\Seeders\PatientHistoryQuestionSeeder;
use Illuminate\Support\Facades\Artisan;
use Mockery\Matcher\Contains;
use PSpell\Config;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Artisan::call('passport:client', ['--provider' => 'admins',  '--personal' => true, '--name' => 'Admin Personal Access Client']);

        SiteSetting::create([
            'mobile_number' => '+970594151094',
            'email' => 'abed@tebfact.com',
            'whatsapp' => 'https://wa.me/+970594151094',
            'facebook' => 'https://www.facebook.com/tebfact',
            'twitter' => 'https://twitter.com/tebfact',
            'instagram' => 'https://www.instagram.com/tebfact/',
            'website' => 'https://tebfact.com/',
        ]);

        Admin::create([
            'full_name' => 'Dermx Super Admin',
            'email' => 'info@dermx.com',
            'password' => bcrypt('dermx@2024'),
        ]);
        $this->call([
            PatientHistoryQuestionSeeder::class,
            // PatientHistorySeeder::class,
            MailSeeder::class,
            PageSeeder::class,
        ]);
    }
}
