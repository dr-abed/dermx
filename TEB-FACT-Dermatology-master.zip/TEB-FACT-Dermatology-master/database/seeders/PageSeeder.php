<?php

namespace Database\Seeders;

use App\Models\Page;
use Illuminate\Database\Seeder;

class PageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Page::create([
            'slug' => 'privacy-policy',
            'status' => 1,
            'en' => [
                'title' => 'Privacy Policy',
                'description' => 'Privacy Policy',
            ],
            'ar' => [
                'title' => 'سياسة الخصوصية',
                'description' => 'سياسة الخصوصية',
            ],
        ]);

        Page::create([
            'slug' => 'terms-and-conditions',
            'status' => 1,
            'en' => [
                'title' => 'Terms and Conditions',
                'description' => 'Terms and Conditions',
            ],
            'ar' => [
                'title' => 'الشروط والأحكام',
                'description' => 'الشروط والأحكام',
            ],
        ]);

        Page::create([
            'slug' => 'about-us',
            'status' => 1,
            'en' => [
                'title' => 'About Us',
                'description' => 'About Us',
            ],
            'ar' => [
                'title' => 'من نحن',
                'description' => 'من نحن',
            ],
        ]);
    }
}
