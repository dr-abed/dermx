<?php

namespace Database\Seeders;

use App\Models\EmailTemplate;
use Illuminate\Database\Seeder;

class MailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        EmailTemplate::create([
            'type'             =>  'contact_message',
            'ar' => [
                'template_name'    =>  'رسالة تواصل',
                'subject'          =>  'رسالة تواصل',
                'body'             =>  '<p><strong>مرحبا</strong></p>
                                            <p><strong>لقد استلمت هذا الإيميل لأننا استقبلنا رسالة تواصل جديدة من موقعك.</strong></p>
                                        ',
            ],
            'en' => [
                'template_name'    =>  'Contact Message',
                'subject'          =>  'Contact Message',
                'body'             =>  '<p><strong>Hello</strong></p>
                                            <p><strong>You are receiving this email because we received a new contact message from your website.</strong></p>
                                        ',
            ],
        ]);

        EmailTemplate::create([
            'type'             =>  'reply_contact_message',
            'ar' => [
                'template_name'    =>  'رد على رسالة تواصل',
                'subject'          =>  'رد على رسالة تواصل',
                'body'             =>  '<p><strong>مرحبا</strong></p>
                                            <p><strong>لقد استلمت هذا الإيميل لأننا قمنا بالرد على رسالة تواصل من موقعك.</strong></p>
                                            <p>{%message%}</p>
                                        ',
            ],
            'en' => [
                'template_name'    =>  'Reply Contact Message',
                'subject'          =>  'Reply Contact Message',
                'body'             =>  '<p><strong>Hello</strong></p>
                                            <p><strong>You are receiving this email because we replied to a contact message from your website.</strong></p>
                                            <p><strong>Your message:</strong></p>
                                            <p>{%message%}</p>
                                        ',
            ],
        ]);
    }
}
