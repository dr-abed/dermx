<?php

namespace Database\Seeders;

use App\Models\PatientHistoryQuestion;
use Illuminate\Database\Seeder;

class PatientHistoryQuestionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل لديك حساسية لأي مواد أو أدوية؟',
            ],
            'en' => [
                'question' => 'Do you have any allergies to any substances or medications?',
            ],
        ]);
        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل تتناول أي أدوية حالياً؟',
            ],
            'en' => [
                'question' => 'Are you currently taking any medications?',
            ],
        ]);
        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل تعاني من حب الشباب أو أي أمراض جلدية أخرى؟',
            ],
            'en' => [
                'question' => 'Do you have acne or any other skin conditions?',
            ],
        ]);
        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل لديك تاريخ عائلي من الأمراض الجلدية؟',
            ],
            'en' => [
                'question' => 'Do you have a family history of skin conditions?',
            ],
        ]);
        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل تستخدم أي منتجات للعناية بالبشرة حالياً؟',
            ],
            'en' => [
                'question' => 'Are you currently using any skincare products?',
            ],
        ]);
        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل تعرضت للشمس بشكل كبير في الأشهر الأخيرة؟',
            ],
            'en' => [
                'question' => 'Have you had significant sun exposure in recent months?',
            ],
        ]);
        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل تعرضت لأي إصابات أو تعرضت لضربة على بشرتك مؤخراً؟',
            ],
            'en' => [
                'question' => 'Have you had any injuries or been hit on your skin recently?',
            ],
        ]);
        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل أجريت أي عمليات جراحية أو إجراءات طبية تشمل جلدك مؤخراً؟',
            ],
            'en' => [
                'question' => 'Have you had any surgeries or medical procedures involving your skin recently?',
            ],
        ]);
        PatientHistoryQuestion::create([
            'type' => 2,
            'ar' => [
                'question' => 'هل تدخن أو كنت تدخن في السابق؟',
            ],
            'en' => [
                'question' => 'Do you smoke or have you ever smoked in the past?',
            ],
        ]);

        PatientHistoryQuestion::create([
            'type' => 0,
            'ar' => [
                'question' => 'اكتب ان كنت تعاني من اي مرض مزمن او تتناول اي دواء حالياً؟',
            ],
            'en' => [
                'question' => 'Write if you have any chronic disease or are currently taking any medication?',
            ],
        ]);
    }
}
