<?php

namespace Database\Seeders;

use App\Models\Article;
use Illuminate\Database\Seeder;

class ArticleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Article::create([
            // 'image' => 'https://cdn.altibbi.com/cdn/cache/1000x500/image/2021/03/26/024e26dee63aa17222bd0df840acef07.png.webp',
            'dermatologist_id' => 1,
            'ar' => [
                'title' => 'فهم الحالات الجلدية الشائعة: دليل شامل',
                'description' => 'تهدف هذه المقالة إلى تقديم نظرة عامة شاملة عن الأمراض الجلدية الشائعة وأسبابها وأعراضها وخيارات العلاج المتاحة. الجلد ، باعتباره أكبر عضو في جسم الإنسان ، عرضة لمجموعة واسعة من الاضطرابات والأمراض. على هذا النحو ، من الضروري فهم هذه الشروط لتسهيل التشخيص المبكر والإدارة الفعالة وتعزيز صحة الجلد بشكل عام. من خلال استكشاف الأمراض الجلدية المختلفة مثل حب الشباب والأكزيما والصدفية والالتهابات الفطرية ، تهدف هذه المقالة إلى تزويد القراء بمعرفة قيمة لتحديد هذه المشكلات ومعالجتها على الفور. علاوة على ذلك ، سيسلط الضوء على الأبحاث والتطورات الناشئة في طب الأمراض الجلدية ، مع التركيز على أهمية البحث عن مشورة طبية متخصصة للتشخيص الدقيق وخطط العلاج المخصصة. سواء كنت متخصصًا في الرعاية الصحية ، أو متحمسًا للعناية بالبشرة ، أو شخصًا يبحث عن معلومات موثوقة حول الأمراض الجلدية ، فإن هذه المقالة ستكون بمثابة مصدر قيم لفهم وإدارة مشاكل الجلد الشائعة بشكل فعال.'
            ],
            'en' => [
                'title' => 'Understanding Common Dermatological Conditions: A Comprehensive Guide',
                'description' => 'This article aims to provide a comprehensive overview of common dermatological conditions, their causes, symptoms, and available treatment options. Skin, being the largest organ of the human body, is susceptible to a wide range of disorders and diseases. As such, it is crucial to understand these conditions to facilitate early diagnosis, effective management, and promote overall skin health. By exploring various dermatological conditions such as acne, eczema, psoriasis, and fungal infections, this article intends to equip readers with valuable knowledge to identify and address these issues promptly. Furthermore, it will shed light on emerging research and advancements in dermatology, emphasizing the importance of seeking professional medical advice for accurate diagnosis and tailored treatment plans. Whether you are a healthcare professional, a skincare enthusiast, or someone seeking reliable information about dermatological conditions, this article will serve as a valuable resource for understanding and managing common skin issues effectively.',
            ],
        ]);

        Article::create([
            // 'image' => 'https://aquatherapy.store/wp-content/uploads/2022/01/skin-type.jpg',
            'dermatologist_id' => 2,
            'ar' => [
                'title' => 'اعرف نوع بشرتك وكيفية العناية بها',
                'description' => 'تعد البشرة الجافة والدهنية والمختلطة والحساسة أنواع البشرة الأربعة الرئيسية التي يمكن أن تكون عليها بشرتك. يمكن لكل نوع أن يتفاعل بشكل مختلف مع العوامل الخارجية والمنتجات العناية بالبشرة. لذلك ، من المهم فهم نوع بشرتك لتحديد أفضل الطرق للعناية بها. يمكن للعوامل الوراثية والبيئية والهرمونية أن تلعب جميعًا دورًا في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك.',
            ],
            'en' => [
                'title' => 'Know Your Skin Type and How to Care for It',
                'description' => 'Dry, oily, combination, and sensitive skin are the four main skin types that your skin can fall under. Each type can react differently to external factors and skincare products. Therefore, it is important to understand your skin type to determine the best ways to care for it. Genetic, environmental, and hormonal factors can all play a role in determining your skin type. Genetic, environmental, and hormonal factors can all play a role in determining your skin type. Genetic, environmental, and hormonal factors can all play a role in determining your skin type. Genetic, environmental, and hormonal factors can all play a role in determining your skin type. Genetic, environmental, and hormonal factors can all play a role in determining your skin type. Genetic, environmental, and hormonal factors can all play a role in determining your skin type. Genetic, environmental, and hormonal factors can all play a role in determining your skin type.',
            ],
        ]);

        Article::create([
            // 'image' => 'https://cdn.salla.sa/rRjZy/tSlzdYi8hMGinjhziOiHuBPDTnhjbvnRvweGNvdG.jpg',
            'dermatologist_id' => 3,
            'ar' => [
                'title' => 'التعرف على البشرة الدهنية وكيفية العناية بها',
                'description' => 'تعد البشرة الدهنية واحدة من أربعة أنواع رئيسية من البشرة. تنتج البشرة الدهنية زيوتًا إضافية ، مما يجعلها أكثر عرضة للحبوب والرؤوس السوداء والرؤوس البيضاء. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك.',
            ],
            'en' => [
                'title' => 'Know Your Oily Skin Type and How to Care for It',
                'description' => 'Oily skin is one of four main skin types. Oily skin produces extra oils, making it more prone to pimples, blackheads, and whiteheads. Genetic, environmental, and hormonal factors can all play a role in determining your skin type. Genetic, environmental, and hormonal factors can all play a role in determining your skin type. Genetic, environmental, and hormonal factors can all play a role in determining your skin type.',
            ]
        ]);

        Article::create([
            // 'image' => 'https://raqyi.com/wp-content/uploads/2017/03/5-%D8%AE%D8%B7%D9%88%D8%A7%D8%AA-%D9%85%D9%86-%D8%A3%D8%AC%D9%84-%D8%A7%D9%84%D8%B9%D9%86%D8%A7%D9%8A%D8%A9-%D8%A8%D8%A7%D9%84%D8%A8%D8%B4%D8%B1%D8%A9-%D9%84%D9%84%D8%B1%D8%AC%D8%A7%D9%84-%D9%88%D8%A7%D9%84%D8%AD%D8%B5%D9%88%D9%84-%D8%B9%D9%84%D9%89-%D9%88%D8%AC%D9%87-%D9%85%D8%AA%D8%A3%D9%84%D9%82.jpg',
            'dermatologist_id' => 4,
            'ar' => [
                'title' => 'التعرف على البشرة الجافة وكيفية العناية بها',
                'description' => 'تعد البشرة الجافة واحدة من أربعة أنواع رئيسية من البشرة. تنتج البشرة الجافة زيوتًا أقل ، مما يجعلها أكثر عرضة للتجاعيد والخطوط الدقيقة والتهيج. يمكن أن يكون للعوامل الوراثية والبيئية والهرمونية جميعًا دور في تحديد نوع بشرتك.',
            ],
            'en' => [
                'title' => 'Know Your Dry Skin Type and How to Care for It',
                'description' => 'Dry skin is one of four main skin types. Dry skin produces less oils, making it more prone to wrinkles, fine lines, and irritation. Genetic, environmental, and hormonal factors can all play a role in determining your skin type.',
            ]
        ]);

        Article::create([
            // 'image' => 'https://www.aljazeera.net/wp-content/uploads/2018/05/ecc668e2-f284-4b78-b458-8e3969b7f30e.jpeg?resize=686%2C513&quality=80',
            'dermatologist_id' => 5,
            'ar' => [
                'title' => 'متى يستلزم احمرار الوجه زيارة الطبيب؟',
                'description' => 'يستلزم احمرار الوجه زيارة الطبيب عندما يترافق مع أعراض أخرى مثل الحكة والحرقة والجفاف والتقشر والتهيج والتورم',
            ],
            'en' => [
                'title' => 'When does facial redness require a doctor visit?',
                'description' => 'Facial redness requires a doctor visit when accompanied by other symptoms such as itching, burning, dryness, peeling, irritation and swelling',
            ]
        ]);
    }
}
